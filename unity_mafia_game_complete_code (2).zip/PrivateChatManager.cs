using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Linq;

public class PrivateChatManager : MonoBehaviour
{
    [Header("Private Chat UI")]
    public GameObject privateChatPanel;
    public TMP_InputField privateChatInput;
    public Button sendPrivateButton;
    public Button closePrivateChatButton;
    public Transform targetSelectionParent;
    public GameObject targetTogglePrefab;
    public ScrollRect privateChatScrollRect;
    public Transform privateChatContent;
    public GameObject privateChatMessagePrefab;
    
    private List<string> selectedTargetIds = new List<string>();
    private List<Player> availableTargets = new List<Player>();
    
    void Start()
    {
        sendPrivateButton.onClick.AddListener(OnSendPrivateMessage);
        closePrivateChatButton.onClick.AddListener(OnClosePrivateChat);
    }
    
    public void ShowPrivateChatPanel(List<Player> players, string currentPlayerId)
    {
        privateChatPanel.SetActive(true);
        availableTargets = players.Where(p => p.id != currentPlayerId && p.isAlive).ToList();
        selectedTargetIds.Clear();
        
        SetupTargetSelection();
    }
    
    void SetupTargetSelection()
    {
        // Clear previous toggles
        foreach (Transform child in targetSelectionParent)
        {
            Destroy(child.gameObject);
        }
        
        // Create toggles for each available target
        foreach (var player in availableTargets)
        {
            GameObject toggleObj = Instantiate(targetTogglePrefab, targetSelectionParent);
            Toggle toggle = toggleObj.GetComponent<Toggle>();
            TextMeshProUGUI toggleText = toggleObj.GetComponentInChildren<TextMeshProUGUI>();
            
            toggleText.text = player.username;
            string playerId = player.id;
            
            toggle.onValueChanged.AddListener((bool isOn) => {
                OnTargetToggled(playerId, isOn);
            });
        }
    }
    
    void OnTargetToggled(string playerId, bool isSelected)
    {
        if (isSelected)
        {
            if (!selectedTargetIds.Contains(playerId))
            {
                selectedTargetIds.Add(playerId);
            }
        }
        else
        {
            selectedTargetIds.Remove(playerId);
        }
        
        // Update send button state
        sendPrivateButton.interactable = selectedTargetIds.Count > 0 && !string.IsNullOrEmpty(privateChatInput.text.Trim());
    }
    
    void OnSendPrivateMessage()
    {
        string message = privateChatInput.text.Trim();
        if (string.IsNullOrEmpty(message) || selectedTargetIds.Count == 0) return;
        
        // Send private message through network manager
        StartCoroutine(NetworkManager.Instance.SendChatMessage(
            MafiaGameManager.Instance.currentRoom.code,
            message,
            selectedTargetIds,
            (success) => {
                if (success)
                {
                    // Add message to local chat
                    string targetNames = string.Join(", ", selectedTargetIds.Select(id => 
                        availableTargets.FirstOrDefault(p => p.id == id)?.username ?? "Unknown"));
                    
                    AddPrivateChatMessage($"To {targetNames}", message);
                    privateChatInput.text = "";
                    selectedTargetIds.Clear();
                    
                    // Reset toggles
                    Toggle[] toggles = targetSelectionParent.GetComponentsInChildren<Toggle>();
                    foreach (Toggle toggle in toggles)
                    {
                        toggle.isOn = false;
                    }
                }
            }
        ));
    }
    
    void OnClosePrivateChat()
    {
        privateChatPanel.SetActive(false);
        selectedTargetIds.Clear();
    }
    
    void AddPrivateChatMessage(string sender, string message)
    {
        GameObject messageObj = Instantiate(privateChatMessagePrefab, privateChatContent);
        TextMeshProUGUI messageText = messageObj.GetComponent<TextMeshProUGUI>();
        
        string timestamp = System.DateTime.Now.ToString("HH:mm");
        messageText.text = $"[{timestamp}] {sender}: {message}";
        messageText.color = new Color(0.2f, 0.4f, 0.8f); // Blue for private messages
        
        // Scroll to bottom
        Canvas.ForceUpdateCanvases();
        privateChatScrollRect.verticalNormalizedPosition = 0f;
    }
    
    public void ReceivePrivateMessage(string senderId, string message)
    {
        var sender = availableTargets.FirstOrDefault(p => p.id == senderId);
        if (sender != null)
        {
            AddPrivateChatMessage($"From {sender.username}", message);
            
            // Show notification
            UIManager uiManager = FindObjectOfType<UIManager>();
            if (uiManager != null)
            {
                uiManager.ShowNotification($"Private message from {sender.username}");
            }
        }
    }
}
