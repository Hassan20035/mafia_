using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    [Header("Audio Sources")]
    public AudioSource musicSource;
    public AudioSource sfxSource;
    
    [Header("Music Clips")]
    public AudioClip menuMusic;
    public AudioClip gameplayMusic;
    public AudioClip nightPhaseMusic;
    public AudioClip tensionMusic;
    
    [Header("SFX Clips")]
    public AudioClip buttonClickSFX;
    public AudioClip notificationSFX;
    public AudioClip eliminationSFX;
    public AudioClip victoryMafiaFX;
    public AudioClip victoryTownSFX;
    public AudioClip nightTransitionSFX;
    public AudioClip dayTransitionSFX;
    
    private static AudioManager instance;
    public static AudioManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<AudioManager>();
            }
            return instance;
        }
    }
    
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void Start()
    {
        PlayMusic(menuMusic);
    }
    
    public void PlayMusic(AudioClip clip)
    {
        if (musicSource.clip == clip) return;
        
        StartCoroutine(CrossfadeMusic(clip));
    }
    
    IEnumerator CrossfadeMusic(AudioClip newClip)
    {
        float fadeTime = 1f;
        float startVolume = musicSource.volume;
        
        // Fade out current music
        for (float t = 0; t < fadeTime; t += Time.deltaTime)
        {
            musicSource.volume = Mathf.Lerp(startVolume, 0, t / fadeTime);
            yield return null;
        }
        
        // Switch clip
        musicSource.clip = newClip;
        musicSource.Play();
        
        // Fade in new music
        for (float t = 0; t < fadeTime; t += Time.deltaTime)
        {
            musicSource.volume = Mathf.Lerp(0, startVolume, t / fadeTime);
            yield return null;
        }
    }
    
    public void PlaySFX(AudioClip clip)
    {
        if (clip != null)
        {
            sfxSource.PlayOneShot(clip);
        }
    }
    
    public void PlayButtonClick()
    {
        PlaySFX(buttonClickSFX);
    }
    
    public void PlayNotification()
    {
        PlaySFX(notificationSFX);
    }
    
    public void PlayElimination()
    {
        PlaySFX(eliminationSFX);
    }
    
    public void PlayVictory(bool mafiaWins)
    {
        PlaySFX(mafiaWins ? victoryMafiaFX : victoryTownSFX);
    }
    
    public void PlayPhaseTransition(bool isNight)
    {
        PlaySFX(isNight ? nightTransitionSFX : dayTransitionSFX);
        PlayMusic(isNight ? nightPhaseMusic : gameplayMusic);
    }
}
