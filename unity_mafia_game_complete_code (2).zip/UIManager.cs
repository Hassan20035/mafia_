using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    [Header("Themes")]
    public Color primaryColor = new Color(0.2f, 0.3f, 0.8f);
    public Color secondaryColor = new Color(0.8f, 0.8f, 0.8f);
    public Color accentColor = new Color(0.9f, 0.4f, 0.2f);
    public Color backgroundColor = new Color(0.95f, 0.95f, 0.95f);
    public Color textColor = new Color(0.1f, 0.1f, 0.1f);
    
    [Header("Fonts")]
    public TMP_FontAsset arabicFont;
    public TMP_FontAsset chineseFont;
    public TMP_FontAsset japaneseFont;
    public TMP_FontAsset russianFont;
    public TMP_FontAsset defaultFont;
    
    private string currentLanguage = "en";
    
    void Start()
    {
        ApplyTheme();
    }
    
    public void SetLanguage(string language)
    {
        currentLanguage = language;
        ApplyFonts();
    }
    
    void ApplyTheme()
    {
        // Apply color scheme to all UI elements
        Camera.main.backgroundColor = backgroundColor;
        
        // Apply to buttons
        Button[] buttons = FindObjectsOfType<Button>();
        foreach (Button button in buttons)
        {
            ColorBlock colors = button.colors;
            colors.normalColor = primaryColor;
            colors.highlightedColor = new Color(primaryColor.r * 1.1f, primaryColor.g * 1.1f, primaryColor.b * 1.1f);
            colors.pressedColor = new Color(primaryColor.r * 0.9f, primaryColor.g * 0.9f, primaryColor.b * 0.9f);
            button.colors = colors;
        }
        
        // Apply to input fields
        TMP_InputField[] inputFields = FindObjectsOfType<TMP_InputField>();
        foreach (TMP_InputField inputField in inputFields)
        {
            inputField.textComponent.color = textColor;
        }
        
        // Apply to text components
        TextMeshProUGUI[] texts = FindObjectsOfType<TextMeshProUGUI>();
        foreach (TextMeshProUGUI text in texts)
        {
            if (text.gameObject.name.Contains("Title"))
            {
                text.color = primaryColor;
            }
            else
            {
                text.color = textColor;
            }
        }
    }
    
    void ApplyFonts()
    {
        TMP_FontAsset fontToUse = GetFontForLanguage(currentLanguage);
        
        TextMeshProUGUI[] texts = FindObjectsOfType<TextMeshProUGUI>();
        foreach (TextMeshProUGUI text in texts)
        {
            text.font = fontToUse;
        }
        
        TMP_InputField[] inputFields = FindObjectsOfType<TMP_InputField>();
        foreach (TMP_InputField inputField in inputFields)
        {
            inputField.textComponent.font = fontToUse;
            if (inputField.placeholder != null)
            {
                inputField.placeholder.GetComponent<TextMeshProUGUI>().font = fontToUse;
            }
        }
    }
    
    TMP_FontAsset GetFontForLanguage(string language)
    {
        switch (language)
        {
            case "ar":
                return arabicFont != null ? arabicFont : defaultFont;
            case "zh":
                return chineseFont != null ? chineseFont : defaultFont;
            case "ja":
                return japaneseFont != null ? japaneseFont : defaultFont;
            case "ru":
                return russianFont != null ? russianFont : defaultFont;
            default:
                return defaultFont;
        }
    }
    
    public void ShowNotification(string message, float duration = 3f)
    {
        StartCoroutine(ShowNotificationCoroutine(message, duration));
    }
    
    IEnumerator ShowNotificationCoroutine(string message, float duration)
    {
        // Create notification popup
        GameObject notification = new GameObject("Notification");
        notification.transform.SetParent(transform);
        
        RectTransform rectTransform = notification.AddComponent<RectTransform>();
        rectTransform.anchorMin = new Vector2(0.5f, 0.8f);
        rectTransform.anchorMax = new Vector2(0.5f, 0.8f);
        rectTransform.sizeDelta = new Vector2(300, 60);
        
        Image background = notification.AddComponent<Image>();
        background.color = new Color(0, 0, 0, 0.8f);
        
        GameObject textObj = new GameObject("Text");
        textObj.transform.SetParent(notification.transform);
        
        TextMeshProUGUI text = textObj.AddComponent<TextMeshProUGUI>();
        text.text = message;
        text.color = Color.white;
        text.alignment = TextAlignmentOptions.Center;
        text.font = GetFontForLanguage(currentLanguage);
        
        RectTransform textRect = textObj.GetComponent<RectTransform>();
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = Vector2.zero;
        textRect.offsetMax = Vector2.zero;
        
        // Animate in
        Vector3 startPos = rectTransform.localPosition + Vector3.up * 100;
        Vector3 endPos = rectTransform.localPosition;
        
        float elapsed = 0f;
        while (elapsed < 0.3f)
        {
            elapsed += Time.deltaTime;
            rectTransform.localPosition = Vector3.Lerp(startPos, endPos, elapsed / 0.3f);
            yield return null;
        }
        
        // Wait
        yield return new WaitForSeconds(duration);
        
        // Animate out
        elapsed = 0f;
        while (elapsed < 0.3f)
        {
            elapsed += Time.deltaTime;
            rectTransform.localPosition = Vector3.Lerp(endPos, startPos, elapsed / 0.3f);
            background.color = Color.Lerp(new Color(0, 0, 0, 0.8f), Color.clear, elapsed / 0.3f);
            text.color = Color.Lerp(Color.white, Color.clear, elapsed / 0.3f);
            yield return null;
        }
        
        Destroy(notification);
    }
}
