using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Linq;
using UnityEngine.Networking;
using System;

public class MafiaGameManager : MonoBehaviour
{
    [Header("UI References")]
    public GameObject loginPanel;
    public GameObject gamePanel;
    public GameObject lobbyPanel;
    public GameObject gameplayPanel;
    public GameObject chatPanel;
    public GameObject rolePanel;
    public GameObject votingPanel;
    public GameObject resultsPanel;
    
    [Header("Login UI")]
    public TMP_InputField usernameInput;
    public Button loginButton;
    public TMP_Dropdown languageDropdown;
    public TextMeshProUGUI loginErrorText;
    
    [Header("Lobby UI")]
    public Button createRoomButton;
    public Button joinRoomButton;
    public TMP_InputField roomCodeInput;
    public TextMeshProUGUI playerListText;
    public Button startGameButton;
    public TextMeshProUGUI roomCodeText;
    
    [Header("Gameplay UI")]
    public TextMeshProUGUI phaseText;
    public TextMeshProUGUI roleText;
    public TextMeshProUGUI instructionText;
    public Transform playerButtonsParent;
    public GameObject playerButtonPrefab;
    public Button confirmActionButton;
    
    [Header("Chat UI")]
    public TMP_InputField chatInput;
    public Button sendChatButton;
    public ScrollRect chatScrollRect;
    public Transform chatContent;
    public GameObject chatMessagePrefab;
    public Button privateChatButton;
    public GameObject privateChatPanel;
    public Transform privateChatTargets;
    public GameObject privateChatTargetPrefab;
    
    [Header("Voting UI")]
    public Transform votingButtonsParent;
    public GameObject votingButtonPrefab;
    public TextMeshProUGUI votingResultsText;
    
    [Header("Results UI")]
    public TextMeshProUGUI gameResultText;
    public TextMeshProUGUI playerStatsText;
    public Button playAgainButton;
    public Button backToLobbyButton;
    
    [Header("Player Profile")]
    public TextMeshProUGUI playerNameText;
    public TextMeshProUGUI playerLevelText;
    public Slider playerXPSlider;
    public TextMeshProUGUI playerXPText;
    
    // Game State
    private GameState currentState = GameState.Login;
    private Player localPlayer;
    private List<Player> allPlayers = new List<Player>();
    private Room currentRoom;
    private GamePhase currentPhase = GamePhase.Day;
    private PlayerRole localPlayerRole;
    private Dictionary<string, string> selectedTargets = new Dictionary<string, string>();
    private Dictionary<string, int> votes = new Dictionary<string, int>();
    private List<string> alivePlayers = new List<string>();
    private int dayCount = 1;
    private string currentLanguage = "en";
    
    // Localization
    private Dictionary<string, Dictionary<string, string>> localization;
    
    void Start()
    {
        InitializeLocalization();
        SetupUI();
        ShowLoginPanel();
    }
    
    void InitializeLocalization()
    {
        localization = new Dictionary<string, Dictionary<string, string>>
        {
            ["en"] = new Dictionary<string, string>
            {
                ["welcome"] = "Welcome to Mafia Game",
                ["username"] = "Username (6-18 characters)",
                ["login"] = "Login",
                ["create_room"] = "Create Room",
                ["join_room"] = "Join Room",
                ["room_code"] = "Room Code",
                ["start_game"] = "Start Game",
                ["mafia"] = "Mafia",
                ["detective"] = "Detective",
                ["doctor"] = "Doctor",
                ["citizen"] = "Citizen",
                ["narrator"] = "Narrator",
                ["night_phase"] = "Night Phase",
                ["day_phase"] = "Day Phase - Discussion",
                ["voting_phase"] = "Voting Phase",
                ["mafia_wins"] = "Mafia Wins!",
                ["town_wins"] = "Town Wins!",
                ["level"] = "Level",
                ["xp"] = "XP",
                ["send"] = "Send",
                ["vote"] = "Vote",
                ["confirm"] = "Confirm",
                ["private_chat"] = "Private Chat",
                ["select_target"] = "Select your target",
                ["select_protection"] = "Select who to protect",
                ["select_investigation"] = "Select who to investigate",
                ["mafia_wake_up"] = "Mafia, wake up and choose your victim",
                ["detective_wake_up"] = "Detective, wake up and choose who to investigate",
                ["doctor_wake_up"] = "Doctor, wake up and choose who to protect",
                ["everyone_sleep"] = "Everyone goes to sleep",
                ["discussion_time"] = "Discussion time - Talk about who might be the mafia",
                ["voting_time"] = "Time to vote - Choose who to eliminate",
                ["player_eliminated"] = "has been eliminated",
                ["player_killed"] = "was killed during the night",
                ["player_saved"] = "was saved by the doctor",
                ["is_mafia"] = "is a member of the mafia",
                ["is_not_mafia"] = "is not a member of the mafia",
                ["tie_vote"] = "Tie vote! Suspected players must defend themselves",
                ["username_taken"] = "Username is already taken",
                ["username_invalid"] = "Username must be 6-18 characters",
                ["room_not_found"] = "Room not found",
                ["game_in_progress"] = "Game already in progress",
                ["waiting_for_players"] = "Waiting for more players...",
                ["minimum_players"] = "Need at least 4 players to start"
            },
            ["ar"] = new Dictionary<string, string>
            {
                ["welcome"] = "مرحباً بك في لعبة المافيا",
                ["username"] = "اسم المستخدم (6-18 حرف)",
                ["login"] = "تسجيل الدخول",
                ["create_room"] = "إنشاء غرفة",
                ["join_room"] = "انضمام لغرفة",
                ["room_code"] = "رمز الغرفة",
                ["start_game"] = "بدء اللعبة",
                ["mafia"] = "المافيا",
                ["detective"] = "الشيخ",
                ["doctor"] = "الطبيب",
                ["citizen"] = "المواطن الصالح",
                ["narrator"] = "الراوي",
                ["night_phase"] = "مرحلة الليل",
                ["day_phase"] = "مرحلة النهار - المناقشة",
                ["voting_phase"] = "مرحلة التصويت",
                ["mafia_wins"] = "المافيا تفوز!",
                ["town_wins"] = "المدينة تفوز!",
                ["level"] = "المستوى",
                ["xp"] = "نقاط الخبرة",
                ["send"] = "إرسال",
                ["vote"] = "تصويت",
                ["confirm"] = "تأكيد",
                ["private_chat"] = "محادثة خاصة",
                ["select_target"] = "اختر هدفك",
                ["select_protection"] = "اختر من تريد حمايته",
                ["select_investigation"] = "اختر من تريد التحقيق معه",
                ["mafia_wake_up"] = "المافيا، استيقظوا واختاروا ضحيتكم",
                ["detective_wake_up"] = "الشيخ، استيقظ واختر من تريد التحقيق معه",
                ["doctor_wake_up"] = "الطبيب، استيقظ واختر من تريد حمايته",
                ["everyone_sleep"] = "الجميع ينام",
                ["discussion_time"] = "وقت المناقشة - تحدثوا عن من قد يكون المافيا",
                ["voting_time"] = "وقت التصويت - اختاروا من تريدون إقصاءه",
                ["player_eliminated"] = "تم إقصاؤه",
                ["player_killed"] = "قُتل خلال الليل",
                ["player_saved"] = "أنقذه الطبيب",
                ["is_mafia"] = "عضو في المافيا",
                ["is_not_mafia"] = "ليس عضواً في المافيا",
                ["tie_vote"] = "تعادل في التصويت! على المشتبه بهم الدفاع عن أنفسهم",
                ["username_taken"] = "اسم المستخدم مُستخدم بالفعل",
                ["username_invalid"] = "اسم المستخدم يجب أن يكون 6-18 حرف",
                ["room_not_found"] = "الغرفة غير موجودة",
                ["game_in_progress"] = "اللعبة قيد التشغيل بالفعل",
                ["waiting_for_players"] = "في انتظار المزيد من اللاعبين...",
                ["minimum_players"] = "نحتاج على الأقل 4 لاعبين لبدء اللعبة"
            },
            ["fr"] = new Dictionary<string, string>
            {
                ["welcome"] = "Bienvenue au jeu de Mafia",
                ["username"] = "Nom d'utilisateur (6-18 caractères)",
                ["login"] = "Connexion",
                ["create_room"] = "Créer une salle",
                ["join_room"] = "Rejoindre une salle",
                ["room_code"] = "Code de la salle",
                ["start_game"] = "Commencer le jeu",
                ["mafia"] = "Mafia",
                ["detective"] = "Détective",
                ["doctor"] = "Docteur",
                ["citizen"] = "Citoyen",
                ["narrator"] = "Narrateur",
                ["night_phase"] = "Phase de nuit",
                ["day_phase"] = "Phase de jour - Discussion",
                ["voting_phase"] = "Phase de vote",
                ["mafia_wins"] = "La Mafia gagne!",
                ["town_wins"] = "La ville gagne!",
                ["level"] = "Niveau",
                ["xp"] = "XP",
                ["send"] = "Envoyer",
                ["vote"] = "Voter",
                ["confirm"] = "Confirmer",
                ["private_chat"] = "Chat privé",
                ["select_target"] = "Sélectionnez votre cible",
                ["select_protection"] = "Sélectionnez qui protéger",
                ["select_investigation"] = "Sélectionnez qui enquêter",
                ["mafia_wake_up"] = "Mafia, réveillez-vous et choisissez votre victime",
                ["detective_wake_up"] = "Détective, réveillez-vous et choisissez qui enquêter",
                ["doctor_wake_up"] = "Docteur, réveillez-vous et choisissez qui protéger",
                ["everyone_sleep"] = "Tout le monde s'endort",
                ["discussion_time"] = "Temps de discussion - Parlez de qui pourrait être la mafia",
                ["voting_time"] = "Temps de vote - Choisissez qui éliminer",
                ["player_eliminated"] = "a été éliminé",
                ["player_killed"] = "a été tué pendant la nuit",
                ["player_saved"] = "a été sauvé par le docteur",
                ["is_mafia"] = "est membre de la mafia",
                ["is_not_mafia"] = "n'est pas membre de la mafia",
                ["tie_vote"] = "Vote égal! Les suspects doivent se défendre",
                ["username_taken"] = "Nom d'utilisateur déjà pris",
                ["username_invalid"] = "Le nom d'utilisateur doit faire 6-18 caractères",
                ["room_not_found"] = "Salle non trouvée",
                ["game_in_progress"] = "Jeu déjà en cours",
                ["waiting_for_players"] = "En attente de plus de joueurs...",
                ["minimum_players"] = "Il faut au moins 4 joueurs pour commencer"
            },
            ["ru"] = new Dictionary<string, string>
            {
                ["welcome"] = "Добро пожаловать в игру Мафия",
                ["username"] = "Имя пользователя (6-18 символов)",
                ["login"] = "Войти",
                ["create_room"] = "Создать комнату",
                ["join_room"] = "Присоединиться к комнате",
                ["room_code"] = "Код комнаты",
                ["start_game"] = "Начать игру",
                ["mafia"] = "Мафия",
                ["detective"] = "Детектив",
                ["doctor"] = "Доктор",
                ["citizen"] = "Мирный житель",
                ["narrator"] = "Ведущий",
                ["night_phase"] = "Ночная фаза",
                ["day_phase"] = "Дневная фаза - Обсуждение",
                ["voting_phase"] = "Фаза голосования",
                ["mafia_wins"] = "Мафия побеждает!",
                ["town_wins"] = "Город побеждает!",
                ["level"] = "Уровень",
                ["xp"] = "Опыт",
                ["send"] = "Отправить",
                ["vote"] = "Голосовать",
                ["confirm"] = "Подтвердить",
                ["private_chat"] = "Личный чат",
                ["select_target"] = "Выберите цель",
                ["select_protection"] = "Выберите кого защитить",
                ["select_investigation"] = "Выберите кого проверить",
                ["mafia_wake_up"] = "Мафия, просыпайтесь и выбирайте жертву",
                ["detective_wake_up"] = "Детектив, просыпайтесь и выбирайте кого проверить",
                ["doctor_wake_up"] = "Доктор, просыпайтесь и выбирайте кого защитить",
                ["everyone_sleep"] = "Все засыпают",
                ["discussion_time"] = "Время обсуждения - Обсудите кто может быть мафией",
                ["voting_time"] = "Время голосования - Выберите кого исключить",
                ["player_eliminated"] = "был исключен",
                ["player_killed"] = "был убит ночью",
                ["player_saved"] = "был спасен доктором",
                ["is_mafia"] = "является членом мафии",
                ["is_not_mafia"] = "не является членом мафии",
                ["tie_vote"] = "Ничья! Подозреваемые должны защищаться",
                ["username_taken"] = "Имя пользователя занято",
                ["username_invalid"] = "Имя должно быть 6-18 символов",
                ["room_not_found"] = "Комната не найдена",
                ["game_in_progress"] = "Игра уже идет",
                ["waiting_for_players"] = "Ожидание игроков...",
                ["minimum_players"] = "Нужно минимум 4 игрока"
            },
            ["zh"] = new Dictionary<string, string>
            {
                ["welcome"] = "欢迎来到黑手党游戏",
                ["username"] = "用户名 (6-18个字符)",
                ["login"] = "登录",
                ["create_room"] = "创建房间",
                ["join_room"] = "加入房间",
                ["room_code"] = "房间代码",
                ["start_game"] = "开始游戏",
                ["mafia"] = "黑手党",
                ["detective"] = "侦探",
                ["doctor"] = "医生",
                ["citizen"] = "平民",
                ["narrator"] = "主持人",
                ["night_phase"] = "夜晚阶段",
                ["day_phase"] = "白天阶段 - 讨论",
                ["voting_phase"] = "投票阶段",
                ["mafia_wins"] = "黑手党获胜！",
                ["town_wins"] = "城镇获胜！",
                ["level"] = "等级",
                ["xp"] = "经验值",
                ["send"] = "发送",
                ["vote"] = "投票",
                ["confirm"] = "确认",
                ["private_chat"] = "私聊",
                ["select_target"] = "选择你的目标",
                ["select_protection"] = "选择要保护的人",
                ["select_investigation"] = "选择要调查的人",
                ["mafia_wake_up"] = "黑手党，醒来选择你们的受害者",
                ["detective_wake_up"] = "侦探，醒来选择要调查的人",
                ["doctor_wake_up"] = "医生，醒来选择要保护的人",
                ["everyone_sleep"] = "所有人都睡觉",
                ["discussion_time"] = "讨论时间 - 谈论谁可能是黑手党",
                ["voting_time"] = "投票时间 - 选择要淘汰的人",
                ["player_eliminated"] = "被淘汰了",
                ["player_killed"] = "在夜晚被杀死了",
                ["player_saved"] = "被医生救了",
                ["is_mafia"] = "是黑手党成员",
                ["is_not_mafia"] = "不是黑手党成员",
                ["tie_vote"] = "平票！嫌疑人必须为自己辩护",
                ["username_taken"] = "用户名已被使用",
                ["username_invalid"] = "用户名必须是6-18个字符",
                ["room_not_found"] = "房间未找到",
                ["game_in_progress"] = "游戏已在进行中",
                ["waiting_for_players"] = "等待更多玩家...",
                ["minimum_players"] = "至少需要4名玩家开始游戏"
            },
            ["ja"] = new Dictionary<string, string>
            {
                ["welcome"] = "マフィアゲームへようこそ",
                ["username"] = "ユーザー名 (6-18文字)",
                ["login"] = "ログイン",
                ["create_room"] = "ルーム作成",
                ["join_room"] = "ルーム参加",
                ["room_code"] = "ルームコード",
                ["start_game"] = "ゲーム開始",
                ["mafia"] = "マフィア",
                ["detective"] = "探偵",
                ["doctor"] = "医者",
                ["citizen"] = "市民",
                ["narrator"] = "司会者",
                ["night_phase"] = "夜のフェーズ",
                ["day_phase"] = "昼のフェーズ - 議論",
                ["voting_phase"] = "投票フェーズ",
                ["mafia_wins"] = "マフィアの勝利！",
                ["town_wins"] = "町の勝利！",
                ["level"] = "レベル",
                ["xp"] = "経験値",
                ["send"] = "送信",
                ["vote"] = "投票",
                ["confirm"] = "確認",
                ["private_chat"] = "プライベートチャット",
                ["select_target"] = "ターゲットを選択",
                ["select_protection"] = "守る人を選択",
                ["select_investigation"] = "調査する人を選択",
                ["mafia_wake_up"] = "マフィア、目を覚まして犠牲者を選んでください",
                ["detective_wake_up"] = "探偵、目を覚まして調査する人を選んでください",
                ["doctor_wake_up"] = "医者、目を覚まして守る人を選んでください",
                ["everyone_sleep"] = "みんな眠ります",
                ["discussion_time"] = "議論の時間 - 誰がマフィアかもしれないか話し合ってください",
                ["voting_time"] = "投票の時間 - 排除する人を選んでください",
                ["player_eliminated"] = "が排除されました",
                ["player_killed"] = "が夜に殺されました",
                ["player_saved"] = "が医者に救われました",
                ["is_mafia"] = "はマフィアのメンバーです",
                ["is_not_mafia"] = "はマフィアのメンバーではありません",
                ["tie_vote"] = "同票！容疑者は自分を弁護しなければなりません",
                ["username_taken"] = "ユーザー名は既に使用されています",
                ["username_invalid"] = "ユーザー名は6-18文字である必要があります",
                ["room_not_found"] = "ルームが見つかりません",
                ["game_in_progress"] = "ゲームは既に進行中です",
                ["waiting_for_players"] = "プレイヤーを待っています...",
                ["minimum_players"] = "開始するには最低4人のプレイヤーが必要です"
            }
        };
    }
    
    void SetupUI()
    {
        // Setup login UI
        loginButton.onClick.AddListener(OnLoginClicked);
        languageDropdown.onValueChanged.AddListener(OnLanguageChanged);
        
        // Setup lobby UI
        createRoomButton.onClick.AddListener(OnCreateRoomClicked);
        joinRoomButton.onClick.AddListener(OnJoinRoomClicked);
        startGameButton.onClick.AddListener(OnStartGameClicked);
        
        // Setup chat UI
        sendChatButton.onClick.AddListener(OnSendChatClicked);
        privateChatButton.onClick.AddListener(OnPrivateChatClicked);
        
        // Setup gameplay UI
        confirmActionButton.onClick.AddListener(OnConfirmActionClicked);
        
        // Setup results UI
        playAgainButton.onClick.AddListener(OnPlayAgainClicked);
        backToLobbyButton.onClick.AddListener(OnBackToLobbyClicked);
        
        // Initialize language dropdown
        languageDropdown.options.Clear();
        languageDropdown.options.Add(new TMP_Dropdown.OptionData("English"));
        languageDropdown.options.Add(new TMP_Dropdown.OptionData("العربية"));
        languageDropdown.options.Add(new TMP_Dropdown.OptionData("Français"));
        languageDropdown.options.Add(new TMP_Dropdown.OptionData("Русский"));
        languageDropdown.options.Add(new TMP_Dropdown.OptionData("中文"));
        languageDropdown.options.Add(new TMP_Dropdown.OptionData("日本語"));
    }
    
    void OnLanguageChanged(int index)
    {
        string[] languages = { "en", "ar", "fr", "ru", "zh", "ja" };
        currentLanguage = languages[index];
        UpdateUITexts();
    }
    
    void UpdateUITexts()
    {
        // Update all UI texts based on current language
        var texts = localization[currentLanguage];
        
        // Login panel
        usernameInput.placeholder.GetComponent<TextMeshProUGUI>().text = texts["username"];
        loginButton.GetComponentInChildren<TextMeshProUGUI>().text = texts["login"];
        
        // Lobby panel
        createRoomButton.GetComponentInChildren<TextMeshProUGUI>().text = texts["create_room"];
        joinRoomButton.GetComponentInChildren<TextMeshProUGUI>().text = texts["join_room"];
        startGameButton.GetComponentInChildren<TextMeshProUGUI>().text = texts["start_game"];
        
        // Chat panel
        sendChatButton.GetComponentInChildren<TextMeshProUGUI>().text = texts["send"];
        privateChatButton.GetComponentInChildren<TextMeshProUGUI>().text = texts["private_chat"];
        
        // Gameplay panel
        confirmActionButton.GetComponentInChildren<TextMeshProUGUI>().text = texts["confirm"];
        
        // Results panel
        playAgainButton.GetComponentInChildren<TextMeshProUGUI>().text = "Play Again";
        backToLobbyButton.GetComponentInChildren<TextMeshProUGUI>().text = "Back to Lobby";
    }
    
    string GetLocalizedText(string key)
    {
        if (localization.ContainsKey(currentLanguage) && localization[currentLanguage].ContainsKey(key))
        {
            return localization[currentLanguage][key];
        }
        return key;
    }
    
    void OnLoginClicked()
    {
        string username = usernameInput.text.Trim();
        
        if (username.Length < 6 || username.Length > 18)
        {
            ShowError(GetLocalizedText("username_invalid"));
            return;
        }
        
        StartCoroutine(LoginPlayer(username));
    }
    
    IEnumerator LoginPlayer(string username)
    {
        // Check if username is available
        bool isAvailable = yield return StartCoroutine(CheckUsernameAvailability(username));
        
        if (!isAvailable)
        {
            ShowError(GetLocalizedText("username_taken"));
            yield break;
        }
        
        // Create player
        localPlayer = new Player
        {
            id = System.Guid.NewGuid().ToString(),
            username = username,
            level = PlayerPrefs.GetInt("PlayerLevel_" + username, 1),
            xp = PlayerPrefs.GetInt("PlayerXP_" + username, 0),
            isAlive = true
        };
        
        UpdatePlayerProfile();
        ShowLobbyPanel();
    }
    
    IEnumerator CheckUsernameAvailability(string username)
    {
        // Simulate server check - in real implementation, check against server
        yield return new WaitForSeconds(0.5f);
        
        // For demo purposes, reject some common names
        string[] takenNames = { "admin", "moderator", "mafia", "detective" };
        return !takenNames.Contains(username.ToLower());
    }
    
    void UpdatePlayerProfile()
    {
        playerNameText.text = localPlayer.username;
        playerLevelText.text = GetLocalizedText("level") + " " + localPlayer.level;
        
        int xpForCurrentLevel = GetXPRequiredForLevel(localPlayer.level);
        int xpForNextLevel = GetXPRequiredForLevel(localPlayer.level + 1);
        int currentLevelXP = localPlayer.xp - xpForCurrentLevel;
        int xpNeededForNext = xpForNextLevel - xpForCurrentLevel;
        
        playerXPSlider.value = (float)currentLevelXP / xpNeededForNext;
        playerXPText.text = $"{currentLevelXP}/{xpNeededForNext} {GetLocalizedText("xp")}";
    }
    
    int GetXPRequiredForLevel(int level)
    {
        // Exponential XP curve - gets harder as you level up
        return Mathf.RoundToInt(100 * Mathf.Pow(1.15f, level - 1));
    }
    
    void OnCreateRoomClicked()
    {
        StartCoroutine(CreateRoom());
    }
    
    IEnumerator CreateRoom()
    {
        string roomCode = GenerateRoomCode();
        currentRoom = new Room
        {
            code = roomCode,
            hostId = localPlayer.id,
            players = new List<Player> { localPlayer },
            gameState = GameState.Lobby,
            maxPlayers = 12
        };
        
        roomCodeText.text = GetLocalizedText("room_code") + ": " + roomCode;
        UpdatePlayerList();
        
        yield return null;
    }
    
    void OnJoinRoomClicked()
    {
        string roomCode = roomCodeInput.text.Trim().ToUpper();
        if (string.IsNullOrEmpty(roomCode))
        {
            ShowError("Please enter a room code");
            return;
        }
        
        StartCoroutine(JoinRoom(roomCode));
    }
    
    IEnumerator JoinRoom(string roomCode)
    {
        // Simulate joining room - in real implementation, connect to server
        yield return new WaitForSeconds(0.5f);
        
        // For demo, create a mock room
        currentRoom = new Room
        {
            code = roomCode,
            hostId = "host123",
            players = new List<Player> { localPlayer },
            gameState = GameState.Lobby,
            maxPlayers = 12
        };
        
        roomCodeText.text = GetLocalizedText("room_code") + ": " + roomCode;
        UpdatePlayerList();
    }
    
    string GenerateRoomCode()
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        string result = "";
        for (int i = 0; i < 6; i++)
        {
            result += chars[UnityEngine.Random.Range(0, chars.Length)];
        }
        return result;
    }
    
    void UpdatePlayerList()
    {
        string playerList = "";
        foreach (var player in currentRoom.players)
        {
            playerList += player.username + " (" + GetLocalizedText("level") + " " + player.level + ")\n";
        }
        playerListText.text = playerList;
        
        startGameButton.interactable = currentRoom.players.Count >= 4 && currentRoom.hostId == localPlayer.id;
    }
    
    void OnStartGameClicked()
    {
        if (currentRoom.players.Count < 4)
        {
            ShowError(GetLocalizedText("minimum_players"));
            return;
        }
        
        StartGame();
    }
    
    void StartGame()
    {
        AssignRoles();
        alivePlayers = currentRoom.players.Select(p => p.id).ToList();
        currentPhase = GamePhase.Night;
        dayCount = 1;
        
        ShowGameplayPanel();
        StartNightPhase();
    }
    
    void AssignRoles()
    {
        int playerCount = currentRoom.players.Count;
        List<PlayerRole> roles = new List<PlayerRole>();
        
        // Calculate role distribution
        int mafiaCount = Mathf.Max(1, playerCount / 4);
        int detectiveCount = Mathf.Max(1, playerCount / 4);
        int doctorCount = Mathf.Max(1, playerCount / 4);
        int citizenCount = playerCount - mafiaCount - detectiveCount - doctorCount;
        
        // Add roles to list
        for (int i = 0; i < mafiaCount; i++) roles.Add(PlayerRole.Mafia);
        for (int i = 0; i < detectiveCount; i++) roles.Add(PlayerRole.Detective);
        for (int i = 0; i < doctorCount; i++) roles.Add(PlayerRole.Doctor);
        for (int i = 0; i < citizenCount; i++) roles.Add(PlayerRole.Citizen);
        
        // Shuffle roles
        for (int i = 0; i < roles.Count; i++)
        {
            PlayerRole temp = roles[i];
            int randomIndex = UnityEngine.Random.Range(i, roles.Count);
            roles[i] = roles[randomIndex];
            roles[randomIndex] = temp;
        }
        
        // Assign roles to players
        for (int i = 0; i < currentRoom.players.Count; i++)
        {
            currentRoom.players[i].role = roles[i];
            if (currentRoom.players[i].id == localPlayer.id)
            {
                localPlayerRole = roles[i];
            }
        }
    }
    
    void StartNightPhase()
    {
        currentPhase = GamePhase.Night;
        phaseText.text = GetLocalizedText("night_phase") + " - " + GetLocalizedText("day") + " " + dayCount;
        
        StartCoroutine(NightSequence());
    }
    
    IEnumerator NightSequence()
    {
        // Everyone sleeps
        instructionText.text = GetLocalizedText("everyone_sleep");
        yield return new WaitForSeconds(2f);
        
        // Mafia phase
        if (localPlayerRole == PlayerRole.Mafia)
        {
            instructionText.text = GetLocalizedText("mafia_wake_up");
            ShowPlayerSelection(PlayerRole.Mafia, "select_target");
            yield return new WaitUntil(() => selectedTargets.ContainsKey("mafia"));
        }
        else
        {
            instructionText.text = GetLocalizedText("mafia_wake_up");
            yield return new WaitForSeconds(10f);
        }
        
        // Detective phase
        if (localPlayerRole == PlayerRole.Detective)
        {
            instructionText.text = GetLocalizedText("detective_wake_up");
            ShowPlayerSelection(PlayerRole.Detective, "select_investigation");
            yield return new WaitUntil(() => selectedTargets.ContainsKey("detective"));
        }
        else
        {
            instructionText.text = GetLocalizedText("detective_wake_up");
            yield return new WaitForSeconds(10f);
        }
        
        // Doctor phase
        if (localPlayerRole == PlayerRole.Doctor)
        {
            instructionText.text = GetLocalizedText("doctor_wake_up");
            ShowPlayerSelection(PlayerRole.Doctor, "select_protection");
            yield return new WaitUntil(() => selectedTargets.ContainsKey("doctor"));
        }
        else
        {
            instructionText.text = GetLocalizedText("doctor_wake_up");
            yield return new WaitForSeconds(10f);
        }
        
        // Process night actions
        ProcessNightActions();
        
        // Start day phase
        StartDayPhase();
    }
    
    void ShowPlayerSelection(PlayerRole role, string instructionKey)
    {
        instructionText.text = GetLocalizedText(instructionKey);
        
        // Clear previous buttons
        foreach (Transform child in playerButtonsParent)
        {
            Destroy(child.gameObject);
        }
        
        // Create buttons for alive players (excluding self for most roles)
        foreach (var player in currentRoom.players)
        {
            if (!alivePlayers.Contains(player.id)) continue;
            if (role != PlayerRole.Doctor && player.id == localPlayer.id) continue;
            
            GameObject buttonObj = Instantiate(playerButtonPrefab, playerButtonsParent);
            Button button = buttonObj.GetComponent<Button>();
            TextMeshProUGUI buttonText = buttonObj.GetComponentInChildren<TextMeshProUGUI>();
            
            buttonText.text = player.username;
            string playerId = player.id;
            
            button.onClick.AddListener(() => OnPlayerSelected(role, playerId));
        }
        
        confirmActionButton.gameObject.SetActive(true);
    }
    
    void OnPlayerSelected(PlayerRole role, string playerId)
    {
        string roleKey = role.ToString().ToLower();
        selectedTargets[roleKey] = playerId;
        
        // Update button colors to show selection
        foreach (Transform child in playerButtonsParent)
        {
            Button button = child.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            button.colors = colors;
        }
        
        // Highlight selected button
        Button selectedButton = playerButtonsParent.GetComponentsInChildren<Button>()
            .FirstOrDefault(b => b.GetComponentInChildren<TextMeshProUGUI>().text == 
                currentRoom.players.FirstOrDefault(p => p.id == playerId)?.username);
        
        if (selectedButton != null)
        {
            ColorBlock colors = selectedButton.colors;
            colors.normalColor = Color.green;
            selectedButton.colors = colors;
        }
    }
    
    void OnConfirmActionClicked()
    {
        // Hide selection UI
        foreach (Transform child in playerButtonsParent)
        {
            Destroy(child.gameObject);
        }
        confirmActionButton.gameObject.SetActive(false);
    }
    
    void ProcessNightActions()
    {
        // In real implementation, this would be handled by server
        // For demo, simulate night results
        
        string killedPlayerId = selectedTargets.ContainsKey("mafia") ? selectedTargets["mafia"] : null;
        string protectedPlayerId = selectedTargets.ContainsKey("doctor") ? selectedTargets["doctor"] : null;
        string investigatedPlayerId = selectedTargets.ContainsKey("detective") ? selectedTargets["detective"] : null;
        
        // Process kill (if not protected)
        if (!string.IsNullOrEmpty(killedPlayerId) && killedPlayerId != protectedPlayerId)
        {
            alivePlayers.Remove(killedPlayerId);
            var killedPlayer = currentRoom.players.FirstOrDefault(p => p.id == killedPlayerId);
            if (killedPlayer != null)
            {
                killedPlayer.isAlive = false;
                AddChatMessage("System", killedPlayer.username + " " + GetLocalizedText("player_killed"));
            }
        }
        else if (!string.IsNullOrEmpty(killedPlayerId) && killedPlayerId == protectedPlayerId)
        {
            var savedPlayer = currentRoom.players.FirstOrDefault(p => p.id == killedPlayerId);
            if (savedPlayer != null)
            {
                AddChatMessage("System", savedPlayer.username + " " + GetLocalizedText("player_saved"));
            }
        }
        
        // Process investigation (only detective sees result)
        if (!string.IsNullOrEmpty(investigatedPlayerId) && localPlayerRole == PlayerRole.Detective)
        {
            var investigatedPlayer = currentRoom.players.FirstOrDefault(p => p.id == investigatedPlayerId);
            if (investigatedPlayer != null)
            {
                string result = investigatedPlayer.role == PlayerRole.Mafia ? 
                    GetLocalizedText("is_mafia") : GetLocalizedText("is_not_mafia");
                AddPrivateChatMessage("Narrator", investigatedPlayer.username + " " + result);
            }
        }
        
        selectedTargets.Clear();
    }
    
    void StartDayPhase()
    {
        currentPhase = GamePhase.Day;
        phaseText.text = GetLocalizedText("day_phase") + " - " + GetLocalizedText("day") + " " + dayCount;
        instructionText.text = GetLocalizedText("discussion_time");
        
        // Check win conditions
        if (CheckWinConditions()) return;
        
        // Start discussion timer
        StartCoroutine(DayPhaseTimer());
    }
    
    IEnumerator DayPhaseTimer()
    {
        // Discussion phase (60 seconds)
        yield return new WaitForSeconds(60f);
        
        // Start voting phase
        StartVotingPhase();
    }
    
    void StartVotingPhase()
    {
        currentPhase = GamePhase.Voting;
        phaseText.text = GetLocalizedText("voting_phase");
        instructionText.text = GetLocalizedText("voting_time");
        
        ShowVotingUI();
    }
    
    void ShowVotingUI()
    {
        votingPanel.SetActive(true);
        
        // Clear previous voting buttons
        foreach (Transform child in votingButtonsParent)
        {
            Destroy(child.gameObject);
        }
        
        // Create voting buttons for alive players
        foreach (var player in currentRoom.players)
        {
            if (!alivePlayers.Contains(player.id)) continue;
            
            GameObject buttonObj = Instantiate(votingButtonPrefab, votingButtonsParent);
            Button button = buttonObj.GetComponent<Button>();
            TextMeshProUGUI buttonText = buttonObj.GetComponentInChildren<TextMeshProUGUI>();
            
            buttonText.text = player.username;
            string playerId = player.id;
            
            button.onClick.AddListener(() => OnVoteClicked(playerId));
        }
    }
    
    void OnVoteClicked(string playerId)
    {
        // In real implementation, send vote to server
        // For demo, simulate voting
        
        var votedPlayer = currentRoom.players.FirstOrDefault(p => p.id == playerId);
        if (votedPlayer != null)
        {
            AddChatMessage("System", localPlayer.username + " voted for " + votedPlayer.username);
        }
        
        votingPanel.SetActive(false);
        
        // Simulate vote counting
        StartCoroutine(ProcessVoting());
    }
    
    IEnumerator ProcessVoting()
    {
        yield return new WaitForSeconds(3f);
        
        // Simulate vote results
        var alivePlayers = currentRoom.players.Where(p => this.alivePlayers.Contains(p.id)).ToList();
        if (alivePlayers.Count > 0)
        {
            var eliminatedPlayer = alivePlayers[UnityEngine.Random.Range(0, alivePlayers.Count)];
            this.alivePlayers.Remove(eliminatedPlayer.id);
            eliminatedPlayer.isAlive = false;
            
            AddChatMessage("System", eliminatedPlayer.username + " " + GetLocalizedText("player_eliminated"));
            
            // Award XP for surviving the day
            if (localPlayer.isAlive)
            {
                AwardXP(10);
            }
        }
        
        // Check win conditions
        if (CheckWinConditions()) return;
        
        // Start next night
        dayCount++;
        StartNightPhase();
    }
    
    bool CheckWinConditions()
    {
        var alivePlayerObjects = currentRoom.players.Where(p => alivePlayers.Contains(p.id)).ToList();
        var aliveMafia = alivePlayerObjects.Where(p => p.role == PlayerRole.Mafia).ToList();
        var aliveTown = alivePlayerObjects.Where(p => p.role != PlayerRole.Mafia).ToList();
        
        if (aliveMafia.Count == 0)
        {
            // Town wins
            EndGame(true);
            return true;
        }
        else if (aliveMafia.Count >= aliveTown.Count)
        {
            // Mafia wins
            EndGame(false);
            return true;
        }
        
        return false;
    }
    
    void EndGame(bool townWins)
    {
        currentState = GameState.GameOver;
        
        string resultText = townWins ? GetLocalizedText("town_wins") : GetLocalizedText("mafia_wins");
        gameResultText.text = resultText;
        
        // Award XP based on result
        bool playerWon = (townWins && localPlayerRole != PlayerRole.Mafia) || 
                        (!townWins && localPlayerRole == PlayerRole.Mafia);
        
        if (playerWon)
        {
            AwardXP(50); // Win bonus
        }
        
        // Show final stats
        string statsText = "";
        foreach (var player in currentRoom.players)
        {
            string roleText = GetLocalizedText(player.role.ToString().ToLower());
            statsText += $"{player.username}: {roleText}\n";
        }
        playerStatsText.text = statsText;
        
        ShowResultsPanel();
    }
    
    void AwardXP(int amount)
    {
        localPlayer.xp += amount;
        
        // Check for level up
        int newLevel = CalculateLevel(localPlayer.xp);
        if (newLevel > localPlayer.level)
        {
            localPlayer.level = newLevel;
            AddChatMessage("System", "Level up! You are now level " + newLevel);
        }
        
        // Save progress
        PlayerPrefs.SetInt("PlayerLevel_" + localPlayer.username, localPlayer.level);
        PlayerPrefs.SetInt("PlayerXP_" + localPlayer.username, localPlayer.xp);
        PlayerPrefs.Save();
        
        UpdatePlayerProfile();
    }
    
    int CalculateLevel(int xp)
    {
        for (int level = 1; level <= 2000; level++)
        {
            if (xp < GetXPRequiredForLevel(level + 1))
            {
                return level;
            }
        }
        return 2000; // Max level
    }
    
    void OnSendChatClicked()
    {
        string message = chatInput.text.Trim();
        if (string.IsNullOrEmpty(message)) return;
        
        AddChatMessage(localPlayer.username, message);
        chatInput.text = "";
    }
    
    void OnPrivateChatClicked()
    {
        privateChatPanel.SetActive(true);
        ShowPrivateChatTargets();
    }
    
    void ShowPrivateChatTargets()
    {
        // Clear previous targets
        foreach (Transform child in privateChatTargets)
        {
            Destroy(child.gameObject);
        }
        
        // Show alive players as potential targets
        foreach (var player in currentRoom.players)
        {
            if (!alivePlayers.Contains(player.id) || player.id == localPlayer.id) continue;
            
            GameObject targetObj = Instantiate(privateChatTargetPrefab, privateChatTargets);
            Toggle toggle = targetObj.GetComponent<Toggle>();
            TextMeshProUGUI targetText = targetObj.GetComponentInChildren<TextMeshProUGUI>();
            
            targetText.text = player.username;
        }
    }
    
    void AddChatMessage(string sender, string message)
    {
        GameObject messageObj = Instantiate(chatMessagePrefab, chatContent);
        TextMeshProUGUI messageText = messageObj.GetComponent<TextMeshProUGUI>();
        
        string timestamp = System.DateTime.Now.ToString("HH:mm");
        messageText.text = $"[{timestamp}] {sender}: {message}";
        
        // Scroll to bottom
        Canvas.ForceUpdateCanvases();
        chatScrollRect.verticalNormalizedPosition = 0f;
    }
    
    void AddPrivateChatMessage(string sender, string message)
    {
        GameObject messageObj = Instantiate(chatMessagePrefab, chatContent);
        TextMeshProUGUI messageText = messageObj.GetComponent<TextMeshProUGUI>();
        
        string timestamp = System.DateTime.Now.ToString("HH:mm");
        messageText.text = $"[{timestamp}] {sender} (Private): {message}";
        messageText.color = Color.blue;
        
        // Scroll to bottom
        Canvas.ForceUpdateCanvases();
        chatScrollRect.verticalNormalizedPosition = 0f;
    }
    
    void OnPlayAgainClicked()
    {
        // Reset game state
        selectedTargets.Clear();
        votes.Clear();
        alivePlayers.Clear();
        dayCount = 1;
        
        // Go back to lobby
        ShowLobbyPanel();
    }
    
    void OnBackToLobbyClicked()
    {
        currentRoom = null;
        ShowLobbyPanel();
    }
    
    void ShowError(string message)
    {
        loginErrorText.text = message;
        loginErrorText.gameObject.SetActive(true);
        StartCoroutine(HideErrorAfterDelay());
    }
    
    IEnumerator HideErrorAfterDelay()
    {
        yield return new WaitForSeconds(3f);
        loginErrorText.gameObject.SetActive(false);
    }
    
    void ShowLoginPanel()
    {
        currentState = GameState.Login;
        loginPanel.SetActive(true);
        lobbyPanel.SetActive(false);
        gameplayPanel.SetActive(false);
        resultsPanel.SetActive(false);
        UpdateUITexts();
    }
    
    void ShowLobbyPanel()
    {
        currentState = GameState.Lobby;
        loginPanel.SetActive(false);
        lobbyPanel.SetActive(true);
        gameplayPanel.SetActive(false);
        resultsPanel.SetActive(false);
    }
    
    void ShowGameplayPanel()
    {
        currentState = GameState.Playing;
        loginPanel.SetActive(false);
        lobbyPanel.SetActive(false);
        gameplayPanel.SetActive(true);
        resultsPanel.SetActive(false);
        
        roleText.text = GetLocalizedText("role") + ": " + GetLocalizedText(localPlayerRole.ToString().ToLower());
    }
    
    void ShowResultsPanel()
    {
        currentState = GameState.GameOver;
        loginPanel.SetActive(false);
        lobbyPanel.SetActive(false);
        gameplayPanel.SetActive(false);
        resultsPanel.SetActive(true);
    }
}

// Data classes
[System.Serializable]
public class Player
{
    public string id;
    public string username;
    public int level;
    public int xp;
    public PlayerRole role;
    public bool isAlive;
}

[System.Serializable]
public class Room
{
    public string code;
    public string hostId;
    public List<Player> players;
    public GameState gameState;
    public int maxPlayers;
}

public enum GameState
{
    Login,
    Lobby,
    Playing,
    GameOver
}

public enum GamePhase
{
    Night,
    Day,
    Voting
}

public enum PlayerRole
{
    Mafia,
    Detective,
    Doctor,
    Citizen
}
