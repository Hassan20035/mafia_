using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class RoleManager : MonoBehaviour
{
    public static RoleDistribution CalculateRoleDistribution(int playerCount)
    {
        RoleDistribution distribution = new RoleDistribution();
        
        if (playerCount < 4)
        {
            // Not enough players
            return distribution;
        }
        
        // Base distribution: roughly 1/4 each role, with citizens filling the rest
        distribution.mafiaCount = Mathf.Max(1, playerCount / 4);
        distribution.detectiveCount = Mathf.Max(1, Mathf.Min(2, playerCount / 6)); // Cap detectives at 2
        distribution.doctorCount = Mathf.Max(1, Mathf.Min(2, playerCount / 6)); // Cap doctors at 2
        distribution.citizenCount = playerCount - distribution.mafiaCount - distribution.detectiveCount - distribution.doctorCount;
        
        // Ensure we don't have too many mafia
        if (distribution.mafiaCount >= playerCount / 2)
        {
            distribution.mafiaCount = (playerCount / 2) - 1;
            distribution.citizenCount = playerCount - distribution.mafiaCount - distribution.detectiveCount - distribution.doctorCount;
        }
        
        return distribution;
    }
    
    public static List<PlayerRole> GenerateRoleList(RoleDistribution distribution)
    {
        List<PlayerRole> roles = new List<PlayerRole>();
        
        // Add roles based on distribution
        for (int i = 0; i < distribution.mafiaCount; i++)
            roles.Add(PlayerRole.Mafia);
        for (int i = 0; i < distribution.detectiveCount; i++)
            roles.Add(PlayerRole.Detective);
        for (int i = 0; i < distribution.doctorCount; i++)
            roles.Add(PlayerRole.Doctor);
        for (int i = 0; i < distribution.citizenCount; i++)
            roles.Add(PlayerRole.Citizen);
        
        // Shuffle the roles
        for (int i = 0; i < roles.Count; i++)
        {
            PlayerRole temp = roles[i];
            int randomIndex = UnityEngine.Random.Range(i, roles.Count);
            roles[i] = roles[randomIndex];
            roles[randomIndex] = temp;
        }
        
        return roles;
    }
    
    public static bool CanRoleActAtNight(PlayerRole role)
    {
        return role == PlayerRole.Mafia || role == PlayerRole.Detective || role == PlayerRole.Doctor;
    }
    
    public static string GetRoleDescription(PlayerRole role, string language)
    {
        Dictionary<PlayerRole, Dictionary<string, string>> descriptions = new Dictionary<PlayerRole, Dictionary<string, string>>
        {
            [PlayerRole.Mafia] = new Dictionary<string, string>
            {
                ["en"] = "You are part of the Mafia. Work with other Mafia members to eliminate the town.",
                ["ar"] = "أنت جزء من المافيا. اعمل مع أعضاء المافيا الآخرين للقضاء على المدينة.",
                ["fr"] = "Vous faites partie de la Mafia. Travaillez avec les autres membres pour éliminer la ville.",
                ["ru"] = "Вы часть Мафии. Работайте с другими членами, чтобы устранить город.",
                ["zh"] = "你是黑手党的一员。与其他黑手党成员合作消灭城镇。",
                ["ja"] = "あなたはマフィアの一員です。他のマフィアメンバーと協力して町を排除してください。"
            },
            [PlayerRole.Detective] = new Dictionary<string, string>
            {
                ["en"] = "You are the Detective. Each night, investigate one player to learn if they are Mafia.",
                ["ar"] = "أنت الشيخ. كل ليلة، احقق مع لاعب واحد لتعرف إذا كان من المافيا.",
                ["fr"] = "Vous êtes le Détective. Chaque nuit, enquêtez sur un joueur pour savoir s'il est Mafia.",
                ["ru"] = "Вы Детектив. Каждую ночь проверяйте одного игрока, чтобы узнать, Мафия ли он.",
                ["zh"] = "你是侦探。每晚调查一名玩家，了解他们是否是黑手党。",
                ["ja"] = "あなたは探偵です。毎晩一人のプレイヤーを調査してマフィアかどうか調べてください。"
            },
            [PlayerRole.Doctor] = new Dictionary<string, string>
            {
                ["en"] = "You are the Doctor. Each night, protect one player from being eliminated by the Mafia.",
                ["ar"] = "أنت الطبيب. كل ليلة، احم لاعباً واحداً من القتل على يد المافيا.",
                ["fr"] = "Vous êtes le Docteur. Chaque nuit, protégez un joueur de l'élimination par la Mafia.",
                ["ru"] = "Вы Доктор. Каждую ночь защищайте одного игрока от устранения Мафией.",
                ["zh"] = "你是医生。每晚保护一名玩家免受黑手党的消灭。",
                ["ja"] = "あなたは医者です。毎晩一人のプレイヤーをマフィアの排除から守ってください。"
            },
            [PlayerRole.Citizen] = new Dictionary<string, string>
            {
                ["en"] = "You are a Citizen. Use discussion and voting to identify and eliminate the Mafia.",
                ["ar"] = "أنت مواطن صالح. استخدم المناقشة والتصويت لتحديد والقضاء على المافيا.",
                ["fr"] = "Vous êtes un Citoyen. Utilisez la discussion et le vote pour identifier et éliminer la Mafia.",
                ["ru"] = "Вы Мирный житель. Используйте обсуждение и голосование для выявления и устранения Мафии.",
                ["zh"] = "你是平民。利用讨论和投票来识别和消灭黑手党。",
                ["ja"] = "あなたは市民です。議論と投票を使ってマフィアを特定し排除してください。"
            }
        };
        
        if (descriptions.ContainsKey(role) && descriptions[role].ContainsKey(language))
        {
            return descriptions[role][language];
        }
        
        return "Unknown role";
    }
}

[System.Serializable]
public class RoleDistribution
{
    public int mafiaCount;
    public int detectiveCount;
    public int doctorCount;
    public int citizenCount;
    
    public int TotalCount => mafiaCount + detectiveCount + doctorCount + citizenCount;
}
