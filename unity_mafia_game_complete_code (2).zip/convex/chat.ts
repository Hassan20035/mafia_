import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const sendMessage = mutation({
  args: {
    roomId: v.id("rooms"),
    senderId: v.optional(v.id("players")),
    senderName: v.string(),
    message: v.string(),
    isPrivate: v.boolean(),
    targetPlayerIds: v.optional(v.array(v.id("players"))),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("chatMessages", {
      roomId: args.roomId,
      senderId: args.senderId,
      senderName: args.senderName,
      message: args.message,
      isPrivate: args.isPrivate,
      targetPlayerIds: args.targetPlayerIds,
      timestamp: Date.now(),
    });

    return true;
  },
});

export const getMessages = query({
  args: { 
    roomId: v.id("rooms"),
    playerId: v.optional(v.id("players")),
  },
  handler: async (ctx, args) => {
    const messages = await ctx.db
      .query("chatMessages")
      .withIndex("by_room_and_timestamp", (q) => q.eq("roomId", args.roomId))
      .order("desc")
      .take(50);

    // Filter messages based on privacy
    const filteredMessages = messages.filter(msg => {
      if (!msg.isPrivate) return true;
      
      if (!args.playerId) return false;
      
      // Show private messages if player is sender or target
      return msg.senderId === args.playerId || 
             (msg.targetPlayerIds && msg.targetPlayerIds.includes(args.playerId));
    });

    return filteredMessages.reverse();
  },
});
