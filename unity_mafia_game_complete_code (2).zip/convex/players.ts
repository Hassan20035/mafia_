import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const createPlayer = mutation({
  args: {
    username: v.string(),
    language: v.string(),
  },
  handler: async (ctx, args) => {
    // Check if username is already taken
    const existingPlayer = await ctx.db
      .query("players")
      .withIndex("by_username", (q) => q.eq("username", args.username))
      .first();

    if (existingPlayer) {
      throw new Error("Username already taken");
    }

    // Validate username length
    if (args.username.length < 3 || args.username.length > 18) {
      throw new Error("Username must be 3-18 characters");
    }

    const playerId = await ctx.db.insert("players", {
      username: args.username,
      level: 1,
      xp: 0,
      gamesPlayed: 0,
      gamesWon: 0,
      isOnline: true,
      lastSeen: Date.now(),
      language: args.language,
    });

    return playerId;
  },
});

export const getPlayer = query({
  args: { playerId: v.id("players") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.playerId);
  },
});

export const updatePlayerStatus = mutation({
  args: {
    playerId: v.id("players"),
    isOnline: v.boolean(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.playerId, {
      isOnline: args.isOnline,
      lastSeen: Date.now(),
    });
  },
});

export const awardXP = mutation({
  args: {
    playerId: v.id("players"),
    xpAmount: v.number(),
    won: v.boolean(),
  },
  handler: async (ctx, args) => {
    const player = await ctx.db.get(args.playerId);
    if (!player) return;

    const newXP = player.xp + args.xpAmount;
    const newLevel = calculateLevel(newXP);
    const newGamesPlayed = player.gamesPlayed + 1;
    const newGamesWon = player.gamesWon + (args.won ? 1 : 0);

    await ctx.db.patch(args.playerId, {
      xp: newXP,
      level: newLevel,
      gamesPlayed: newGamesPlayed,
      gamesWon: newGamesWon,
    });

    return { newLevel, leveledUp: newLevel > player.level };
  },
});

function calculateLevel(xp: number): number {
  for (let level = 1; level <= 100; level++) {
    const xpRequired = Math.floor(100 * Math.pow(1.15, level - 1));
    if (xp < xpRequired) {
      return level - 1;
    }
  }
  return 100;
}
