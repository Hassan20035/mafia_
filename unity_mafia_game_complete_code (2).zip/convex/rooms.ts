import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const createRoom = mutation({
  args: {
    hostId: v.id("players"),
    maxPlayers: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const roomCode = generateRoomCode();
    
    const roomId = await ctx.db.insert("rooms", {
      code: roomCode,
      hostId: args.hostId,
      maxPlayers: args.maxPlayers || 12,
      isActive: true,
      gameStarted: false,
      currentPhase: "lobby",
      dayCount: 0,
      createdAt: Date.now(),
    });

    // Add host to room
    await ctx.db.insert("roomPlayers", {
      roomId,
      playerId: args.hostId,
      isAlive: true,
      joinedAt: Date.now(),
    });

    return { roomId, roomCode };
  },
});

export const joinRoom = mutation({
  args: {
    roomCode: v.string(),
    playerId: v.id("players"),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db
      .query("rooms")
      .withIndex("by_code", (q) => q.eq("code", args.roomCode))
      .first();

    if (!room) {
      throw new Error("Room not found");
    }

    if (!room.isActive) {
      throw new Error("Room is not active");
    }

    if (room.gameStarted) {
      throw new Error("Game already started");
    }

    // Check if player is already in room
    const existingPlayer = await ctx.db
      .query("roomPlayers")
      .withIndex("by_room_and_player", (q) => 
        q.eq("roomId", room._id).eq("playerId", args.playerId))
      .first();

    if (existingPlayer) {
      throw new Error("Already in room");
    }

    // Check room capacity
    const currentPlayers = await ctx.db
      .query("roomPlayers")
      .withIndex("by_room", (q) => q.eq("roomId", room._id))
      .collect();

    if (currentPlayers.length >= room.maxPlayers) {
      throw new Error("Room is full");
    }

    await ctx.db.insert("roomPlayers", {
      roomId: room._id,
      playerId: args.playerId,
      isAlive: true,
      joinedAt: Date.now(),
    });

    return room._id;
  },
});

export const getRoomPlayers = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const roomPlayers = await ctx.db
      .query("roomPlayers")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    const players = await Promise.all(
      roomPlayers.map(async (rp) => {
        const player = await ctx.db.get(rp.playerId);
        return {
          ...player,
          role: rp.role,
          isAlive: rp.isAlive,
          joinedAt: rp.joinedAt,
        };
      })
    );

    return players.filter(p => p !== null);
  },
});

export const getRoom = query({
  args: { roomCode: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_code", (q) => q.eq("code", args.roomCode))
      .first();
  },
});

export const getRoomById = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.roomId);
  },
});

export const startGame = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    const players = await ctx.db
      .query("roomPlayers")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    if (players.length < 4) {
      throw new Error("Need at least 4 players");
    }

    // Assign roles
    const roles = assignRoles(players.length);
    const shuffledRoles = shuffleArray(roles);

    for (let i = 0; i < players.length; i++) {
      await ctx.db.patch(players[i]._id, {
        role: shuffledRoles[i],
      });
    }

    await ctx.db.patch(args.roomId, {
      gameStarted: true,
      currentPhase: "night",
      dayCount: 1,
    });

    return true;
  },
});

export const leaveRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    playerId: v.id("players"),
  },
  handler: async (ctx, args) => {
    const roomPlayer = await ctx.db
      .query("roomPlayers")
      .withIndex("by_room_and_player", (q) => 
        q.eq("roomId", args.roomId).eq("playerId", args.playerId))
      .first();

    if (roomPlayer) {
      await ctx.db.delete(roomPlayer._id);
    }

    // Check if room is empty
    const remainingPlayers = await ctx.db
      .query("roomPlayers")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    if (remainingPlayers.length === 0) {
      await ctx.db.patch(args.roomId, { isActive: false });
    }

    return true;
  },
});

function generateRoomCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < 6; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

function assignRoles(playerCount: number): string[] {
  const roles: string[] = [];
  
  const mafiaCount = Math.max(1, Math.floor(playerCount / 4));
  const detectiveCount = Math.max(1, Math.floor(playerCount / 6));
  const doctorCount = Math.max(1, Math.floor(playerCount / 6));
  const citizenCount = playerCount - mafiaCount - detectiveCount - doctorCount;

  for (let i = 0; i < mafiaCount; i++) roles.push("mafia");
  for (let i = 0; i < detectiveCount; i++) roles.push("detective");
  for (let i = 0; i < doctorCount; i++) roles.push("doctor");
  for (let i = 0; i < citizenCount; i++) roles.push("citizen");

  return roles;
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
