import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  players: defineTable({
    username: v.string(),
    level: v.number(),
    xp: v.number(),
    gamesPlayed: v.number(),
    gamesWon: v.number(),
    isOnline: v.boolean(),
    lastSeen: v.number(),
    language: v.string(),
  }).index("by_username", ["username"]),

  rooms: defineTable({
    code: v.string(),
    hostId: v.id("players"),
    maxPlayers: v.number(),
    isActive: v.boolean(),
    gameStarted: v.boolean(),
    currentPhase: v.string(),
    dayCount: v.number(),
    createdAt: v.number(),
  }).index("by_code", ["code"])
    .index("by_host", ["hostId"]),

  roomPlayers: defineTable({
    roomId: v.id("rooms"),
    playerId: v.id("players"),
    role: v.optional(v.string()),
    isAlive: v.boolean(),
    joinedAt: v.number(),
  }).index("by_room", ["roomId"])
    .index("by_player", ["playerId"])
    .index("by_room_and_player", ["roomId", "playerId"]),

  chatMessages: defineTable({
    roomId: v.id("rooms"),
    senderId: v.optional(v.id("players")),
    senderName: v.string(),
    message: v.string(),
    isPrivate: v.boolean(),
    targetPlayerIds: v.optional(v.array(v.id("players"))),
    timestamp: v.number(),
  }).index("by_room", ["roomId"])
    .index("by_room_and_timestamp", ["roomId", "timestamp"]),

  gameActions: defineTable({
    roomId: v.id("rooms"),
    playerId: v.id("players"),
    phase: v.string(),
    action: v.string(),
    targetId: v.optional(v.id("players")),
    dayCount: v.number(),
    timestamp: v.number(),
  }).index("by_room_and_phase", ["roomId", "phase"])
    .index("by_room_and_day", ["roomId", "dayCount"]),

  votes: defineTable({
    roomId: v.id("rooms"),
    voterId: v.id("players"),
    targetId: v.id("players"),
    dayCount: v.number(),
    timestamp: v.number(),
  }).index("by_room_and_day", ["roomId", "dayCount"])
    .index("by_voter", ["voterId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
