import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { Id } from "./_generated/dataModel";

export const submitNightAction = mutation({
  args: {
    roomId: v.id("rooms"),
    playerId: v.id("players"),
    action: v.string(),
    targetId: v.optional(v.id("players")),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room || room.currentPhase !== "night") {
      throw new Error("Invalid game state");
    }

    // Remove existing action for this player in this phase
    const existingAction = await ctx.db
      .query("gameActions")
      .withIndex("by_room_and_day", (q) => 
        q.eq("roomId", args.roomId).eq("dayCount", room.dayCount))
      .filter((q) => q.eq(q.field("playerId"), args.playerId))
      .filter((q) => q.eq(q.field("phase"), "night"))
      .first();

    if (existingAction) {
      await ctx.db.delete(existingAction._id);
    }

    await ctx.db.insert("gameActions", {
      roomId: args.roomId,
      playerId: args.playerId,
      phase: "night",
      action: args.action,
      targetId: args.targetId,
      dayCount: room.dayCount,
      timestamp: Date.now(),
    });

    return true;
  },
});

export const submitVote = mutation({
  args: {
    roomId: v.id("rooms"),
    voterId: v.id("players"),
    targetId: v.id("players"),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room || room.currentPhase !== "voting") {
      throw new Error("Invalid game state");
    }

    // Remove previous vote if exists
    const existingVote = await ctx.db
      .query("votes")
      .withIndex("by_room_and_day", (q) => 
        q.eq("roomId", args.roomId).eq("dayCount", room.dayCount))
      .filter((q) => q.eq(q.field("voterId"), args.voterId))
      .first();

    if (existingVote) {
      await ctx.db.delete(existingVote._id);
    }

    await ctx.db.insert("votes", {
      roomId: args.roomId,
      voterId: args.voterId,
      targetId: args.targetId,
      dayCount: room.dayCount,
      timestamp: Date.now(),
    });

    return true;
  },
});

export const processNightActions = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    const actions = await ctx.db
      .query("gameActions")
      .withIndex("by_room_and_day", (q) => 
        q.eq("roomId", args.roomId).eq("dayCount", room.dayCount))
      .filter((q) => q.eq(q.field("phase"), "night"))
      .collect();

    let killedPlayerId: Id<"players"> | null = null;
    let protectedPlayerId: Id<"players"> | null = null;

    // Process mafia kill
    const mafiaAction = actions.find(a => a.action === "kill");
    if (mafiaAction?.targetId) {
      killedPlayerId = mafiaAction.targetId;
    }

    // Process doctor protection
    const doctorAction = actions.find(a => a.action === "protect");
    if (doctorAction?.targetId) {
      protectedPlayerId = doctorAction.targetId;
    }

    // Process detective investigation
    const detectiveAction = actions.find(a => a.action === "investigate");
    if (detectiveAction?.targetId) {
      const targetPlayer = await ctx.db
        .query("roomPlayers")
        .withIndex("by_room_and_player", (q) => 
          q.eq("roomId", args.roomId).eq("playerId", detectiveAction.targetId!))
        .first();
      
      if (targetPlayer) {
        // Send private message to detective
        await ctx.db.insert("chatMessages", {
          roomId: args.roomId,
          senderName: "Narrator",
          message: `Investigation result: ${targetPlayer.role === "mafia" ? "This player is mafia!" : "This player is innocent."}`,
          isPrivate: true,
          targetPlayerIds: [detectiveAction.playerId],
          timestamp: Date.now(),
        });
      }
    }

    // Apply kill if not protected
    if (killedPlayerId && killedPlayerId !== protectedPlayerId) {
      const roomPlayer = await ctx.db
        .query("roomPlayers")
        .withIndex("by_room_and_player", (q) => 
          q.eq("roomId", args.roomId).eq("playerId", killedPlayerId))
        .first();

      if (roomPlayer) {
        await ctx.db.patch(roomPlayer._id, { isAlive: false });
        
        const player = await ctx.db.get(killedPlayerId);
        if (player && 'username' in player) {
          await ctx.db.insert("chatMessages", {
            roomId: args.roomId,
            senderName: "System",
            message: `${player.username} was eliminated during the night.`,
            isPrivate: false,
            timestamp: Date.now(),
          });
        }
      }
    } else if (killedPlayerId === protectedPlayerId && killedPlayerId) {
      const player = await ctx.db.get(killedPlayerId);
      if (player && 'username' in player) {
        await ctx.db.insert("chatMessages", {
          roomId: args.roomId,
          senderName: "System",
          message: `${player.username} was saved by the doctor!`,
          isPrivate: false,
          timestamp: Date.now(),
        });
      }
    }

    // Move to day phase
    await ctx.db.patch(args.roomId, {
      currentPhase: "day",
    });

    return true;
  },
});

export const processVoting = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    const votes = await ctx.db
      .query("votes")
      .withIndex("by_room_and_day", (q) => 
        q.eq("roomId", args.roomId).eq("dayCount", room.dayCount))
      .collect();

    // Count votes
    const voteCount: Record<string, number> = {};
    votes.forEach(vote => {
      voteCount[vote.targetId] = (voteCount[vote.targetId] || 0) + 1;
    });

    // Find player with most votes
    let maxVotes = 0;
    let eliminatedPlayerId: Id<"players"> | null = null;
    let tiedPlayers: string[] = [];

    Object.entries(voteCount).forEach(([playerId, count]) => {
      if (count > maxVotes) {
        maxVotes = count;
        eliminatedPlayerId = playerId as Id<"players">;
        tiedPlayers = [playerId];
      } else if (count === maxVotes) {
        tiedPlayers.push(playerId);
      }
    });

    if (tiedPlayers.length > 1) {
      // Handle tie - no elimination
      await ctx.db.insert("chatMessages", {
        roomId: args.roomId,
        senderName: "System",
        message: "Vote tied! No one was eliminated.",
        isPrivate: false,
        timestamp: Date.now(),
      });
    } else if (eliminatedPlayerId) {
      // Eliminate player
      const roomPlayer = await ctx.db
        .query("roomPlayers")
        .withIndex("by_room_and_player", (q) => 
          q.eq("roomId", args.roomId).eq("playerId", eliminatedPlayerId!))
        .first();

      if (roomPlayer) {
        await ctx.db.patch(roomPlayer._id, { isAlive: false });
        
        const player = await ctx.db.get(eliminatedPlayerId);
        if (player && 'username' in player) {
          await ctx.db.insert("chatMessages", {
            roomId: args.roomId,
            senderName: "System",
            message: `${player.username} was eliminated by vote. Role: ${roomPlayer.role}`,
            isPrivate: false,
            timestamp: Date.now(),
          });
        }
      }
    }

    // Check win conditions
    const winResult = await checkWinConditions(ctx, args.roomId);
    if (winResult.gameEnded) {
      await ctx.db.patch(args.roomId, {
        currentPhase: "ended",
        isActive: false,
      });

      await ctx.db.insert("chatMessages", {
        roomId: args.roomId,
        senderName: "System",
        message: winResult.winner === "mafia" ? "Mafia wins!" : "Town wins!",
        isPrivate: false,
        timestamp: Date.now(),
      });

      // Award XP to players
      const roomPlayers = await ctx.db
        .query("roomPlayers")
        .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
        .collect();

      for (const rp of roomPlayers) {
        const won = (winResult.winner === "mafia" && rp.role === "mafia") ||
                    (winResult.winner === "town" && rp.role !== "mafia");
        
        const player = await ctx.db.get(rp.playerId);
        if (player && 'username' in player) {
          const xpAmount = won ? 50 : 20;
          const newXP = player.xp + xpAmount;
          const newLevel = calculateLevel(newXP);
          
          await ctx.db.patch(rp.playerId, {
            xp: newXP,
            level: newLevel,
            gamesPlayed: player.gamesPlayed + 1,
            gamesWon: player.gamesWon + (won ? 1 : 0),
          });
        }
      }
    } else {
      // Continue to next night
      await ctx.db.patch(args.roomId, {
        currentPhase: "night",
        dayCount: room.dayCount + 1,
      });
    }

    return winResult;
  },
});

export const advanceToVoting = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    await ctx.db.patch(args.roomId, {
      currentPhase: "voting",
    });

    return true;
  },
});

async function checkWinConditions(ctx: any, roomId: Id<"rooms">) {
  const allRoomPlayers = await ctx.db
    .query("roomPlayers")
    .withIndex("by_room", (q: any) => q.eq("roomId", roomId))
    .collect();

  const alivePlayers = allRoomPlayers.filter((p: any) => p.isAlive);
  const aliveMafia = alivePlayers.filter((p: any) => p.role === "mafia");
  const aliveTown = alivePlayers.filter((p: any) => p.role !== "mafia");

  if (aliveMafia.length === 0) {
    return { gameEnded: true, winner: "town" };
  } else if (aliveMafia.length >= aliveTown.length) {
    return { gameEnded: true, winner: "mafia" };
  }

  return { gameEnded: false, winner: null };
}

function calculateLevel(xp: number): number {
  for (let level = 1; level <= 100; level++) {
    const xpRequired = Math.floor(100 * Math.pow(1.15, level - 1));
    if (xp < xpRequired) {
      return level - 1;
    }
  }
  return 100;
}
