import React from 'react';
import { localization } from '../utils/localization';

interface PlayerListProps {
  players: any[];
  language: string;
  gameStarted: boolean;
}

export default function PlayerList({ players, language, gameStarted }: PlayerListProps) {
  const getText = (key: string) => {
    return localization[language]?.[key] || key;
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4">
      <h3 className="font-semibold text-gray-800 mb-3">
        {getText('players_in_room')} ({players.length})
      </h3>
      
      <div className="space-y-2">
        {players.map((player, index) => (
          <div 
            key={player._id || index}
            className={`p-3 rounded-lg border ${
              !gameStarted ? 'bg-gray-50' :
              !player.isAlive ? 'bg-red-50 border-red-200' :
              'bg-green-50 border-green-200'
            }`}
          >
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium text-gray-800">{player.username}</p>
                <p className="text-sm text-gray-600">
                  {getText('level')} {player.level || 1}
                </p>
              </div>
              <div className="text-right">
                {gameStarted && (
                  <div className={`text-xs px-2 py-1 rounded ${
                    !player.isAlive ? 'bg-red-200 text-red-800' :
                    'bg-green-200 text-green-800'
                  }`}>
                    {player.isAlive ? 'Alive' : 'Dead'}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
