import React, { useState } from 'react';
import { localization } from '../utils/localization';

interface GameActionsProps {
  room: any;
  player: any;
  currentPlayerData: any;
  roomPlayers: any[];
  language: string;
  onSubmitNightAction: any;
  onSubmitVote: any;
  onProcessNightActions: any;
  onProcessVoting: any;
  onAdvanceToVoting: any;
}

export default function GameActions({
  room,
  player,
  currentPlayerData,
  roomPlayers,
  language,
  onSubmitNightAction,
  onSubmitVote,
  onProcessNightActions,
  onProcessVoting,
  onAdvanceToVoting,
}: GameActionsProps) {
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [actionSubmitted, setActionSubmitted] = useState(false);

  const getText = (key: string) => {
    return localization[language]?.[key] || key;
  };

  const alivePlayers = roomPlayers.filter(p => p.isAlive && p._id !== player.id);
  const alivePlayersIncludingSelf = roomPlayers.filter(p => p.isAlive);

  const handleNightAction = async () => {
    if (!selectedTarget || !currentPlayerData?.role) return;

    let action = '';
    if (currentPlayerData.role === 'mafia') action = 'kill';
    else if (currentPlayerData.role === 'detective') action = 'investigate';
    else if (currentPlayerData.role === 'doctor') action = 'protect';

    try {
      await onSubmitNightAction({
        roomId: room._id,
        playerId: player.id,
        action,
        targetId: selectedTarget,
      });
      setActionSubmitted(true);
      setSelectedTarget(null);
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleVote = async () => {
    if (!selectedTarget) return;

    try {
      await onSubmitVote({
        roomId: room._id,
        voterId: player.id,
        targetId: selectedTarget,
      });
      setActionSubmitted(true);
      setSelectedTarget(null);
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleAdvancePhase = async () => {
    try {
      if (room.currentPhase === 'night') {
        await onProcessNightActions({ roomId: room._id });
      } else if (room.currentPhase === 'voting') {
        await onProcessVoting({ roomId: room._id });
      } else if (room.currentPhase === 'day') {
        await onAdvanceToVoting({ roomId: room._id });
      }
    } catch (error: any) {
      alert(error.message);
    }
  };

  if (!room.gameStarted) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-xl font-bold text-center text-gray-800">
          {getText('waiting_for_host')}
        </h3>
      </div>
    );
  }

  if (room.currentPhase === 'ended') {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">
          {getText('game_ended')}
        </h2>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-xl font-bold mb-4 text-center">
        {getText(room.currentPhase + '_phase')}
      </h3>

      {/* Night Phase Actions */}
      {room.currentPhase === 'night' && currentPlayerData?.role !== 'citizen' && currentPlayerData?.isAlive && (
        <div className="space-y-4">
          <p className="text-center text-gray-700">
            {getText(
              currentPlayerData.role === 'mafia' ? 'select_target' :
              currentPlayerData.role === 'detective' ? 'select_investigation' :
              'select_protection'
            )}
          </p>
          
          {!actionSubmitted ? (
            <>
              <div className="grid grid-cols-2 gap-2">
                {(currentPlayerData.role === 'doctor' ? alivePlayersIncludingSelf : alivePlayers).map((p) => (
                  <button
                    key={p._id}
                    onClick={() => setSelectedTarget(p._id)}
                    className={`p-3 rounded-lg border transition-colors ${
                      selectedTarget === p._id
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-gray-50 text-gray-800 border-gray-300 hover:bg-gray-100'
                    }`}
                  >
                    {p.username}
                  </button>
                ))}
              </div>
              
              <button
                onClick={handleNightAction}
                disabled={!selectedTarget}
                className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
              >
                {getText('confirm_action')}
              </button>
            </>
          ) : (
            <div className="text-center text-green-600 font-medium">
              Action submitted! Waiting for other players...
            </div>
          )}
        </div>
      )}

      {/* Day Phase */}
      {room.currentPhase === 'day' && (
        <div className="text-center">
          <p className="text-gray-700 mb-4">
            Discussion time! Talk about who might be the mafia.
          </p>
          {room.hostId === player.id && (
            <button
              onClick={handleAdvancePhase}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Start Voting
            </button>
          )}
        </div>
      )}

      {/* Voting Phase */}
      {room.currentPhase === 'voting' && currentPlayerData?.isAlive && (
        <div className="space-y-4">
          <p className="text-center text-gray-700">
            {getText('vote_to_eliminate')}
          </p>
          
          {!actionSubmitted ? (
            <>
              <div className="grid grid-cols-2 gap-2">
                {alivePlayers.map((p) => (
                  <button
                    key={p._id}
                    onClick={() => setSelectedTarget(p._id)}
                    className={`p-3 rounded-lg border transition-colors ${
                      selectedTarget === p._id
                        ? 'bg-red-600 text-white border-red-600'
                        : 'bg-gray-50 text-gray-800 border-gray-300 hover:bg-gray-100'
                    }`}
                  >
                    {p.username}
                  </button>
                ))}
              </div>
              
              <button
                onClick={handleVote}
                disabled={!selectedTarget}
                className="w-full bg-red-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
              >
                Vote
              </button>
            </>
          ) : (
            <div className="text-center text-green-600 font-medium">
              Vote submitted! Waiting for other players...
            </div>
          )}
        </div>
      )}

      {/* Host controls for advancing phases */}
      {room.hostId === player.id && room.currentPhase !== 'day' && (
        <div className="mt-4 pt-4 border-t">
          <button
            onClick={handleAdvancePhase}
            className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors"
          >
            {room.currentPhase === 'night' ? 'Process Night Actions' : 'Process Votes'}
          </button>
        </div>
      )}
    </div>
  );
}
