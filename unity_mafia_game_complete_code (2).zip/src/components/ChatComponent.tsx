import React, { useState, useEffect, useRef } from 'react';
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { localization } from '../utils/localization';

interface ChatComponentProps {
  roomId: string;
  playerId: string;
  playerName: string;
  messages: any[];
  language: string;
}

export default function ChatComponent({ 
  roomId, 
  playerId, 
  playerName, 
  messages, 
  language 
}: ChatComponentProps) {
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const sendMessage = useMutation(api.chat.sendMessage);

  const getText = (key: string) => {
    return localization[language]?.[key] || key;
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;

    try {
      await sendMessage({
        roomId: roomId as any,
        senderId: playerId as any,
        senderName: playerName,
        message: newMessage.trim(),
        isPrivate: false,
      });
      setNewMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg">
      <div className="p-4 border-b">
        <h3 className="font-semibold text-gray-800">Chat</h3>
      </div>
      
      {/* Messages */}
      <div className="h-64 overflow-y-auto p-4 space-y-2">
        {messages.map((message, index) => (
          <div key={index} className={`${message.isPrivate ? 'bg-blue-50 border-l-4 border-blue-400 pl-3' : ''}`}>
            <div className="flex items-start gap-2">
              <span className="text-xs text-gray-500 mt-1">
                {formatTime(message.timestamp)}
              </span>
              <div className="flex-1">
                <span className={`font-medium ${
                  message.senderName === 'System' ? 'text-red-600' :
                  message.senderName === 'Narrator' ? 'text-purple-600' :
                  'text-gray-800'
                }`}>
                  {message.senderName}:
                </span>
                <span className="ml-2 text-gray-700">{message.message}</span>
                {message.isPrivate && (
                  <span className="ml-2 text-xs text-blue-600 font-medium">
                    (Private)
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="p-4 border-t">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder={getText('type_message')}
            className="flex-1 p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {getText('send_message')}
          </button>
        </form>
      </div>
    </div>
  );
}
