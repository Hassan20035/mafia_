import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { localization } from '../utils/localization';
import ChatComponent from '../components/ChatComponent';
import PlayerList from '../components/PlayerList';
import GameActions from '../components/GameActions';

interface GameScreenProps {
  player: any;
  room: any;
  onLeaveRoom: () => void;
  language: string;
}

export default function GameScreen({ player, room, onLeaveRoom, language }: GameScreenProps) {
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  
  const roomData = useQuery(api.rooms.getRoomById, { roomId: room.id });
  const roomPlayers = useQuery(api.rooms.getRoomPlayers, { roomId: room.id });
  const messages = useQuery(api.chat.getMessages, { 
    roomId: room.id, 
    playerId: player.id 
  });

  const leaveRoom = useMutation(api.rooms.leaveRoom);
  const startGame = useMutation(api.rooms.startGame);
  const submitNightAction = useMutation(api.game.submitNightAction);
  const submitVote = useMutation(api.game.submitVote);
  const processNightActions = useMutation(api.game.processNightActions);
  const processVoting = useMutation(api.game.processVoting);
  const advanceToVoting = useMutation(api.game.advanceToVoting);

  const getText = (key: string) => {
    return localization[language]?.[key] || key;
  };

  const handleLeaveRoom = async () => {
    try {
      await leaveRoom({
        roomId: room.id,
        playerId: player.id,
      });
      onLeaveRoom();
    } catch (error) {
      console.error('Failed to leave room:', error);
    }
  };

  const handleStartGame = async () => {
    try {
      await startGame({ roomId: room.id });
    } catch (error: any) {
      alert(error.message);
    }
  };

  const currentPlayerData = roomPlayers?.find(p => p._id === player.id);
  const isHost = roomData?.hostId === player.id;
  const canStartGame = isHost && !roomData?.gameStarted && (roomPlayers?.length || 0) >= 4;

  if (!roomData || !roomPlayers) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">
                {getText('room_code')}: {room.code}
              </h1>
              <p className="text-gray-600">
                {roomData.gameStarted ? 
                  `${getText(roomData.currentPhase + '_phase')} - Day ${roomData.dayCount}` : 
                  getText('waiting_for_host')
                }
              </p>
            </div>
            <div className="flex gap-2">
              {canStartGame && (
                <button
                  onClick={handleStartGame}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                >
                  {getText('start_game')}
                </button>
              )}
              <button
                onClick={handleLeaveRoom}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                {getText('leave_room')}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Game Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Player Role (if game started) */}
            {roomData.gameStarted && currentPlayerData?.role && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-bold mb-4">{getText('your_role')}</h2>
                <div className="text-center">
                  <div className={`inline-block px-6 py-3 rounded-lg text-white font-bold text-lg ${
                    currentPlayerData.role === 'mafia' ? 'bg-red-600' :
                    currentPlayerData.role === 'detective' ? 'bg-blue-600' :
                    currentPlayerData.role === 'doctor' ? 'bg-green-600' :
                    'bg-gray-600'
                  }`}>
                    {getText(currentPlayerData.role)}
                  </div>
                  <p className="mt-3 text-gray-600">
                    {getText(currentPlayerData.role + '_instruction')}
                  </p>
                </div>
              </div>
            )}

            {/* Game Actions */}
            {roomData.gameStarted && (
              <GameActions
                room={roomData}
                player={player}
                currentPlayerData={currentPlayerData}
                roomPlayers={roomPlayers}
                language={language}
                onSubmitNightAction={submitNightAction}
                onSubmitVote={submitVote}
                onProcessNightActions={processNightActions}
                onProcessVoting={processVoting}
                onAdvanceToVoting={advanceToVoting}
              />
            )}

            {/* Chat */}
            <ChatComponent
              roomId={room.id}
              playerId={player.id}
              playerName={player.username}
              messages={messages || []}
              language={language}
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <PlayerList
              players={roomPlayers}
              language={language}
              gameStarted={roomData.gameStarted}
            />

            {!roomData.gameStarted && (
              <div className="bg-white rounded-lg shadow-lg p-4">
                <h3 className="font-semibold mb-2">{getText('game_rules')}</h3>
                <p className="text-sm text-gray-600">
                  {getText('rules_description')}
                </p>
                {(roomPlayers?.length || 0) < 4 && (
                  <p className="mt-2 text-orange-600 text-sm font-medium">
                    {getText('minimum_players')}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
