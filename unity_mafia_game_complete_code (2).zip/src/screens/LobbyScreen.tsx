import React, { useState } from 'react';
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { localization } from '../utils/localization';

interface LobbyScreenProps {
  player: any;
  onJoinRoom: (room: any) => void;
  language: string;
}

export default function LobbyScreen({ player, onJoinRoom, language }: LobbyScreenProps) {
  const [roomCode, setRoomCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const createRoom = useMutation(api.rooms.createRoom);
  const joinRoom = useMutation(api.rooms.joinRoom);

  const getText = (key: string) => {
    return localization[language]?.[key] || key;
  };

  const handleCreateRoom = async () => {
    setLoading(true);
    setError('');
    
    try {
      const result = await createRoom({
        hostId: player.id,
        maxPlayers: 12,
      });
      
      const room = {
        id: result.roomId,
        code: result.roomCode,
        hostId: player.id,
        isHost: true,
      };
      
      onJoinRoom(room);
    } catch (error: any) {
      setError(error.message || getText('create_room_error'));
    } finally {
      setLoading(false);
    }
  };

  const handleJoinRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!roomCode.trim()) {
      setError(getText('enter_room_code'));
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const roomId = await joinRoom({
        roomCode: roomCode.trim().toUpperCase(),
        playerId: player.id,
      });
      
      const room = {
        id: roomId,
        code: roomCode.trim().toUpperCase(),
        hostId: null,
        isHost: false,
      };
      
      onJoinRoom(room);
    } catch (error: any) {
      setError(error.message || getText('join_room_error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 to-blue-900 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h1 className="text-2xl font-bold text-center text-gray-800 mb-2">
            {getText('welcome_back')}
          </h1>
          <p className="text-xl text-blue-600 text-center font-semibold">
            {player.username}
          </p>
        </div>

        {/* Player Stats */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-sm text-gray-600">{getText('level')}</p>
              <p className="text-2xl font-bold text-gray-800">{player.level || 1}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">{getText('xp')}</p>
              <p className="text-2xl font-bold text-gray-800">{player.xp || 0}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">{getText('games_played')}</p>
              <p className="text-2xl font-bold text-gray-800">{player.gamesPlayed || 0}</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="space-y-4">
            <button
              onClick={handleCreateRoom}
              disabled={loading}
              className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {getText('create_room')}
            </button>

            <div className="text-center text-gray-500">أو / OR</div>

            <form onSubmit={handleJoinRoom} className="space-y-3">
              <input
                type="text"
                value={roomCode}
                onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                placeholder={getText('room_code')}
                maxLength={6}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-center font-mono text-lg"
              />
              <button
                type="submit"
                disabled={loading || !roomCode.trim()}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
              >
                {getText('join_room')}
              </button>
            </form>
          </div>

          {error && (
            <div className="mt-4 text-red-600 text-sm text-center bg-red-50 p-2 rounded">
              {error}
            </div>
          )}
        </div>

        {/* Game Instructions */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="font-semibold text-gray-800 mb-3">{getText('how_to_play')}</h3>
          <p className="text-sm text-gray-600 leading-relaxed">
            {getText('game_instructions')}
          </p>
        </div>
      </div>
    </div>
  );
}
