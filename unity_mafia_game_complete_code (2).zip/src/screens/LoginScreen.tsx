import React, { useState } from 'react';
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { localization } from '../utils/localization';

interface LoginScreenProps {
  onLogin: (player: any) => void;
  language: string;
  onLanguageChange: (language: string) => void;
}

export default function LoginScreen({ onLogin, language, onLanguageChange }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const createPlayer = useMutation(api.players.createPlayer);

  const getText = (key: string) => {
    return localization[language]?.[key] || key;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (username.length < 3 || username.length > 18) {
      setError(getText('username_invalid'));
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const playerId = await createPlayer({
        username: username.trim(),
        language,
      });
      
      const player = {
        id: playerId,
        username: username.trim(),
        language,
      };
      
      onLogin(player);
    } catch (error: any) {
      setError(error.message || getText('login_error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 to-purple-900">
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
          {getText('welcome')}
        </h1>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            اللغة / Language
          </label>
          <select
            value={language}
            onChange={(e) => onLanguageChange(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="en">English</option>
            <option value="ar">العربية</option>
          </select>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {getText('username')}
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder={getText('username_placeholder')}
              maxLength={18}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>

          {error && (
            <div className="text-red-600 text-sm text-center bg-red-50 p-2 rounded">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || username.length < 3}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? getText('loading') : getText('login')}
          </button>
        </form>

        <div className="mt-8 bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold text-gray-800 mb-2">{getText('game_rules')}</h3>
          <p className="text-sm text-gray-600">
            {getText('rules_description')}
          </p>
        </div>
      </div>
    </div>
  );
}
