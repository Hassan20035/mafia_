import React, { useState } from 'react';
import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import LoginScreen from './screens/LoginScreen';
import LobbyScreen from './screens/LobbyScreen';
import GameScreen from './screens/GameScreen';

type GameState = 'login' | 'lobby' | 'game';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('login');
  const [currentPlayer, setCurrentPlayer] = useState<any>(null);
  const [currentRoom, setCurrentRoom] = useState<any>(null);
  const [language, setLanguage] = useState('en');

  const handleLogin = (player: any) => {
    setCurrentPlayer(player);
    setGameState('lobby');
  };

  const handleJoinRoom = (room: any) => {
    setCurrentRoom(room);
    setGameState('game');
  };

  const handleLeaveRoom = () => {
    setCurrentRoom(null);
    setGameState('lobby');
  };

  const renderCurrentScreen = () => {
    switch (gameState) {
      case 'login':
        return (
          <LoginScreen 
            onLogin={handleLogin}
            language={language}
            onLanguageChange={setLanguage}
          />
        );
      case 'lobby':
        return (
          <LobbyScreen 
            player={currentPlayer}
            onJoinRoom={handleJoinRoom}
            language={language}
          />
        );
      case 'game':
        return (
          <GameScreen 
            player={currentPlayer}
            room={currentRoom}
            onLeaveRoom={handleLeaveRoom}
            language={language}
          />
        );
      default:
        return (
          <LoginScreen 
            onLogin={handleLogin}
            language={language}
            onLanguageChange={setLanguage}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {renderCurrentScreen()}
    </div>
  );
}
