export const localization: Record<string, Record<string, string>> = {
  en: {
    welcome: "Welcome to Mafia Game",
    username: "Username",
    username_placeholder: "Enter your username (3-18 characters)",
    login: "Login",
    loading: "Loading...",
    create_room: "Create Room",
    join_room: "Join Room",
    room_code: "Room Code",
    enter_room_code: "Please enter a room code",
    start_game: "Start Game",
    leave_room: "Leave Room",
    players_in_room: "Players in Room",
    waiting_for_host: "Waiting for host to start the game...",
    minimum_players: "Need at least 4 players to start",
    
    // Roles
    mafia: "Mafia",
    detective: "Detective", 
    doctor: "Doctor",
    citizen: "Citizen",
    
    // Game phases
    night_phase: "Night Phase",
    day_phase: "Day Phase - Discussion",
    voting_phase: "Voting Phase",
    game_ended: "Game Ended",
    
    // Actions
    select_target: "Select your target",
    select_protection: "Select who to protect",
    select_investigation: "Select who to investigate",
    confirm_action: "Confirm Action",
    vote_to_eliminate: "Vote to Eliminate",
    
    // Messages
    mafia_wins: "Mafia Wins!",
    town_wins: "Town Wins!",
    player_eliminated: "was eliminated",
    player_killed: "was killed during the night",
    player_saved: "was saved by the doctor",
    vote_tied: "Vote tied! No one was eliminated.",
    
    // Stats
    level: "Level",
    xp: "XP",
    games_played: "Games Played",
    games_won: "Games Won",
    
    // Chat
    send_message: "Send Message",
    type_message: "Type your message...",
    
    // Errors
    username_invalid: "Username must be 3-18 characters",
    username_taken: "Username already taken",
    login_error: "Login failed",
    create_room_error: "Failed to create room",
    join_room_error: "Failed to join room",
    room_not_found: "Room not found",
    game_already_started: "Game already started",
    room_full: "Room is full",
    
    // Instructions
    your_role: "Your Role",
    mafia_instruction: "You are Mafia! Eliminate the town during night phases.",
    detective_instruction: "You are Detective! Investigate players to find the mafia.",
    doctor_instruction: "You are Doctor! Protect players from being eliminated.",
    citizen_instruction: "You are Citizen! Help find and eliminate the mafia.",
    
    welcome_back: "Welcome Back",
    how_to_play: "How to Play",
    game_rules: "Game Rules",
    rules_description: "Mafia is a social deduction game. The town must find and eliminate all mafia members, while the mafia tries to eliminate the town.",
    game_instructions: "Create or join a room to start playing. You need at least 4 players to begin a game.",
  },
  
  ar: {
    welcome: "مرحباً بك في لعبة المافيا",
    username: "اسم المستخدم",
    username_placeholder: "أدخل اسم المستخدم (3-18 حرف)",
    login: "تسجيل الدخول",
    loading: "جاري التحميل...",
    create_room: "إنشاء غرفة",
    join_room: "انضمام لغرفة",
    room_code: "رمز الغرفة",
    enter_room_code: "يرجى إدخال رمز الغرفة",
    start_game: "بدء اللعبة",
    leave_room: "مغادرة الغرفة",
    players_in_room: "اللاعبون في الغرفة",
    waiting_for_host: "في انتظار المضيف لبدء اللعبة...",
    minimum_players: "نحتاج على الأقل 4 لاعبين لبدء اللعبة",
    
    // Roles
    mafia: "المافيا",
    detective: "المحقق",
    doctor: "الطبيب", 
    citizen: "المواطن",
    
    // Game phases
    night_phase: "مرحلة الليل",
    day_phase: "مرحلة النهار - المناقشة",
    voting_phase: "مرحلة التصويت",
    game_ended: "انتهت اللعبة",
    
    // Actions
    select_target: "اختر هدفك",
    select_protection: "اختر من تريد حمايته",
    select_investigation: "اختر من تريد التحقيق معه",
    confirm_action: "تأكيد الإجراء",
    vote_to_eliminate: "صوت للإقصاء",
    
    // Messages
    mafia_wins: "المافيا تفوز!",
    town_wins: "المدينة تفوز!",
    player_eliminated: "تم إقصاؤه",
    player_killed: "قُتل خلال الليل",
    player_saved: "أنقذه الطبيب",
    vote_tied: "تعادل في التصويت! لم يتم إقصاء أحد.",
    
    // Stats
    level: "المستوى",
    xp: "نقاط الخبرة",
    games_played: "الألعاب المُلعبة",
    games_won: "الألعاب المكسوبة",
    
    // Chat
    send_message: "إرسال رسالة",
    type_message: "اكتب رسالتك...",
    
    // Errors
    username_invalid: "اسم المستخدم يجب أن يكون 3-18 حرف",
    username_taken: "اسم المستخدم مُستخدم بالفعل",
    login_error: "فشل تسجيل الدخول",
    create_room_error: "فشل في إنشاء الغرفة",
    join_room_error: "فشل في الانضمام للغرفة",
    room_not_found: "الغرفة غير موجودة",
    game_already_started: "اللعبة بدأت بالفعل",
    room_full: "الغرفة ممتلئة",
    
    // Instructions
    your_role: "دورك",
    mafia_instruction: "أنت من المافيا! اقضِ على المدينة خلال مراحل الليل.",
    detective_instruction: "أنت المحقق! احقق مع اللاعبين لتجد المافيا.",
    doctor_instruction: "أنت الطبيب! احمِ اللاعبين من الإقصاء.",
    citizen_instruction: "أنت مواطن! ساعد في العثور على المافيا وإقصائها.",
    
    welcome_back: "مرحباً بعودتك",
    how_to_play: "كيفية اللعب",
    game_rules: "قواعد اللعبة",
    rules_description: "المافيا هي لعبة استنتاج اجتماعي. يجب على المدينة العثور على جميع أعضاء المافيا وإقصائهم، بينما تحاول المافيا إقصاء المدينة.",
    game_instructions: "أنشئ غرفة أو انضم لغرفة لبدء اللعب. تحتاج على الأقل 4 لاعبين لبدء اللعبة.",
  }
};
