using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameTimer : MonoBehaviour
{
    [Header("Timer UI")]
    public TextMeshProUGUI timerText;
    public Slider timerSlider;
    public Image timerFill;
    
    [Header("Timer Settings")]
    public float discussionTime = 120f; // 2 minutes
    public float votingTime = 60f; // 1 minute
    public float nightActionTime = 30f; // 30 seconds per role
    
    private float currentTime;
    private float maxTime;
    private bool isTimerActive;
    private System.Action onTimerComplete;
    
    void Update()
    {
        if (isTimerActive)
        {
            currentTime -= Time.deltaTime;
            
            if (currentTime <= 0)
            {
                currentTime = 0;
                isTimerActive = false;
                onTimerComplete?.Invoke();
            }
            
            UpdateTimerUI();
        }
    }
    
    public void StartTimer(float duration, System.Action onComplete)
    {
        maxTime = duration;
        currentTime = duration;
        isTimerActive = true;
        onTimerComplete = onComplete;
        
        gameObject.SetActive(true);
        UpdateTimerUI();
    }
    
    public void StopTimer()
    {
        isTimerActive = false;
        gameObject.SetActive(false);
    }
    
    void UpdateTimerUI()
    {
        // Update text
        int minutes = Mathf.FloorToInt(currentTime / 60);
        int seconds = Mathf.FloorToInt(currentTime % 60);
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
        
        // Update slider
        timerSlider.value = currentTime / maxTime;
        
        // Update color based on remaining time
        float timeRatio = currentTime / maxTime;
        if (timeRatio > 0.5f)
        {
            timerFill.color = Color.green;
        }
        else if (timeRatio > 0.25f)
        {
            timerFill.color = Color.yellow;
        }
        else
        {
            timerFill.color = Color.red;
        }
    }
    
    public float GetRemainingTime()
    {
        return currentTime;
    }
    
    public bool IsTimerActive()
    {
        return isTimerActive;
    }
}
