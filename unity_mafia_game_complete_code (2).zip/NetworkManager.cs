using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System;

public class NetworkManager : MonoBehaviour
{
    private static NetworkManager instance;
    public static NetworkManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<NetworkManager>();
            }
            return instance;
        }
    }
    
    [Header("Server Settings")]
    public string serverURL = "https://your-convex-deployment.convex.cloud";
    
    private string authToken;
    private string playerId;
    
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    public IEnumerator AuthenticatePlayer(string username, System.Action<bool, string> callback)
    {
        var authData = new
        {
            username = username,
            timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
        };
        
        string jsonData = JsonUtility.ToJson(authData);
        
        using (UnityWebRequest request = new UnityWebRequest(serverURL + "/auth/login", "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            
            yield return request.SendWebRequest();
            
            if (request.result == UnityWebRequest.Result.Success)
            {
                var response = JsonUtility.FromJson<AuthResponse>(request.downloadHandler.text);
                authToken = response.token;
                playerId = response.playerId;
                callback(true, "");
            }
            else
            {
                callback(false, request.error);
            }
        }
    }
    
    public IEnumerator CreateRoom(System.Action<bool, string, string> callback)
    {
        var roomData = new
        {
            hostId = playerId,
            maxPlayers = 12
        };
        
        string jsonData = JsonUtility.ToJson(roomData);
        
        using (UnityWebRequest request = new UnityWebRequest(serverURL + "/rooms/create", "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", "Bearer " + authToken);
            
            yield return request.SendWebRequest();
            
            if (request.result == UnityWebRequest.Result.Success)
            {
                var response = JsonUtility.FromJson<CreateRoomResponse>(request.downloadHandler.text);
                callback(true, response.roomCode, "");
            }
            else
            {
                callback(false, "", request.error);
            }
        }
    }
    
    public IEnumerator JoinRoom(string roomCode, System.Action<bool, string> callback)
    {
        var joinData = new
        {
            roomCode = roomCode,
            playerId = playerId
        };
        
        string jsonData = JsonUtility.ToJson(joinData);
        
        using (UnityWebRequest request = new UnityWebRequest(serverURL + "/rooms/join", "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", "Bearer " + authToken);
            
            yield return request.SendWebRequest();
            
            if (request.result == UnityWebRequest.Result.Success)
            {
                callback(true, "");
            }
            else
            {
                callback(false, request.error);
            }
        }
    }
    
    public IEnumerator SendChatMessage(string roomCode, string message, List<string> targetPlayerIds, System.Action<bool> callback)
    {
        var chatData = new
        {
            roomCode = roomCode,
            senderId = playerId,
            message = message,
            targetPlayerIds = targetPlayerIds,
            isPrivate = targetPlayerIds != null && targetPlayerIds.Count > 0
        };
        
        string jsonData = JsonUtility.ToJson(chatData);
        
        using (UnityWebRequest request = new UnityWebRequest(serverURL + "/chat/send", "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", "Bearer " + authToken);
            
            yield return request.SendWebRequest();
            
            callback(request.result == UnityWebRequest.Result.Success);
        }
    }
    
    public IEnumerator SubmitNightAction(string roomCode, string action, string targetId, System.Action<bool> callback)
    {
        var actionData = new
        {
            roomCode = roomCode,
            playerId = playerId,
            action = action,
            targetId = targetId
        };
        
        string jsonData = JsonUtility.ToJson(actionData);
        
        using (UnityWebRequest request = new UnityWebRequest(serverURL + "/game/night-action", "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", "Bearer " + authToken);
            
            yield return request.SendWebRequest();
            
            callback(request.result == UnityWebRequest.Result.Success);
        }
    }
    
    public IEnumerator SubmitVote(string roomCode, string targetId, System.Action<bool> callback)
    {
        var voteData = new
        {
            roomCode = roomCode,
            voterId = playerId,
            targetId = targetId
        };
        
        string jsonData = JsonUtility.ToJson(voteData);
        
        using (UnityWebRequest request = new UnityWebRequest(serverURL + "/game/vote", "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", "Bearer " + authToken);
            
            yield return request.SendWebRequest();
            
            callback(request.result == UnityWebRequest.Result.Success);
        }
    }
}

// Response classes
[System.Serializable]
public class AuthResponse
{
    public string token;
    public string playerId;
    public bool success;
    public string error;
}

[System.Serializable]
public class CreateRoomResponse
{
    public string roomCode;
    public bool success;
    public string error;
}

[System.Serializable]
public class GameStateResponse
{
    public string phase;
    public List<Player> players;
    public List<string> alivePlayers;
    public int dayCount;
    public bool gameEnded;
    public string winner;
}
