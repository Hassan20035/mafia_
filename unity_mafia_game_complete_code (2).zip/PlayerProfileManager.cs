using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerProfileManager : MonoBehaviour
{
    [Header("Profile UI")]
    public GameObject profilePanel;
    public TextMeshProUGUI profileNameText;
    public Text